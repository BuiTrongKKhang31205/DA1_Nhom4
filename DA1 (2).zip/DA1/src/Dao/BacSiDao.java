/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Entity.BacSiEntity;
import dao.Database;
import java.util.*;
import java.sql.*;
/**
 *
 * @author buitr
 */
public class BacSiDao {
    Connection con = Database.getConnection();
    public List<BacSiEntity> getAllBacSi(){
        List<BacSiEntity> listBS = new ArrayList<>();
        try {

            String sql = "SELECT * FROM BACSI ";
            PreparedStatement pre = con.prepareStatement(sql);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                BacSiEntity bsE = new BacSiEntity(resu.getInt("ID"), resu.getInt("ID_Khoa"), resu.getString("TenBS"),resu.getString("DiaChi"), 
                resu.getString("NgaySinh"), resu.getString("SDT"),resu.getBoolean("GioiTinh"));                
                listBS.add(bsE);
            }
        } catch (SQLException e) {
            System.out.println("Lay du lieu Bac Si that bai" + e);
        }
        return listBS;
    }
    public void add(BacSiEntity bs){
        try {

            String sql = "INSERT INTO BacSi (ID_Khoa, TenBS, DiaChi, NgaySinh, SDT, GioiTinh) VALUES(?,?,?,?,?,?)";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, bs.getIdKhoa());
            pre.setString(2, bs.getTenBS());
            pre.setString(3, bs.getDiaChi());
            pre.setString(4, bs.getNgaySinh());            
            pre.setString(5, bs.getSDT());
            pre.setBoolean(6, bs.isGioiTinh());
            
            if(pre.executeUpdate() > 0){
                System.out.println("INSERT thanh cong");
            }else{
                System.out.println("INSERT that bai");
            }
        } catch (SQLException e) {
            System.out.println("Them bac si that bai" + e);
        }
    }
    public void update(BacSiEntity bs){
        try {

            String sql = "UPDATE BACSI SET ID_Khoa = ?, TenBS = ?, DiaChi = ?, NgaySinhSinh = ?, SDT = ?, GioiTinh = ?, WHERE ID = ?";
            PreparedStatement pre = con.prepareStatement(sql);  
            pre.setInt(1, bs.getId());
            pre.setInt(2, bs.getIdKhoa());
            pre.setString(3, bs.getTenBS());
            pre.setString(4, bs.getDiaChi());
            pre.setString(5, bs.getNgaySinh());            
            pre.setString(6, bs.getSDT());
            pre.setBoolean(7, bs.isGioiTinh());
            
            if(pre.executeUpdate() > 0){
                System.out.println("UPDATE thanh cong");
            }else{
                System.out.println("UPDATE that bai");
            }
        } catch (SQLException e) {
            System.out.println("Cap nhat bac si that bai" + e);
        }
    }
    public void delete(int  id){
        try {

            String sql = "DELETE FROM BacSi WHERE ID = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, id);
            if(pre.executeUpdate() > 0){
                System.out.println("Delete thanh cong");
            }else{
                System.out.println("Delete that bai");
            }
        } catch (SQLException e) {
            System.out.println("Delete that bai" + e);
        }
    }
    public BacSiEntity selectByID(int id){
        try {

            String sql = "SELECT * FROM BacSi WHERE ID = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, id);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                BacSiEntity bsE = new BacSiEntity(resu.getInt("ID"), resu.getInt("ID_Khoa"), resu.getString("TenBS"),resu.getString("DiaChi"), 
                resu.getString("NgaySinh"), resu.getString("SDT"),resu.getBoolean("GioiTinh"));
                return bsE;
            }
            
        } catch (SQLException e) {
            System.out.println("SelectByID that bai" + e);
        }
        return null;
    }
    public BacSiEntity selectByTen(String tenBS){
        try {

            String sql = "SELECT * FROM BacSi WHERE TenBS = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, tenBS);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                BacSiEntity bsE = new BacSiEntity(resu.getInt("ID"), resu.getInt("ID_Khoa"), resu.getString("TenBS"),resu.getString("DiaChi"), 
                resu.getString("NgaySinh"), resu.getString("SDT"),resu.getBoolean("GioiTinh"));
                return bsE;
            }
            
        } catch (SQLException e) {
            System.out.println("SelectByID that bai" + e);
        }
        return null;
    }    
    public  List<BacSiEntity> getBacSiByKhoa(int ID_Khoa){
        List<BacSiEntity> lbs = new ArrayList<>();
        try {

            String sql = "SELECT * FROM BACSI Where ID_Khoa = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, ID_Khoa);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                BacSiEntity bsE = new BacSiEntity(resu.getInt("ID"), resu.getInt("ID_Khoa"), resu.getString("TenBS"),resu.getString("DiaChi"), 
                resu.getString("NgaySinh"), resu.getString("SDT"),resu.getBoolean("GioiTinh"));                
                lbs.add(bsE);
            }
        } catch (SQLException e) {
            System.out.println("Lay du lieu Bac Si that bai" + e);
        }
        return lbs;        
    }
}
