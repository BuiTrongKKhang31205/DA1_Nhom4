/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Entity.SoKhamEntity;
import dao.Database;
import java.util.List;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author buitr
 */
public class SoKhamDao {
    Connection con = Database.getConnection();
    public List<SoKhamEntity> getAllSoKham(){
        List<SoKhamEntity> lsSoKham = new ArrayList<>();
        try {
            String sql = "SELECT * FROM SoKham";
            PreparedStatement pre = con.prepareStatement(sql);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                SoKhamEntity skE = new SoKhamEntity(resu.getInt("ID"), resu.getInt("ID_YTA"), resu.getInt("ID_BN"), resu.getString("TinhTrangBenh"), resu.getInt("ID_khoa"), resu.getInt("ID_BS"),
                        resu.getString("ChiDinh"),resu.getString("ToaThuoc"), resu.getString("ChuanDoan"), resu.getString("NgayKham"), resu.getString("NgayHenKhamLai"), resu.getString("GhiChu"), resu.getString("TrangThai"));
                lsSoKham.add(skE);
            }
        } catch (SQLException e) {
            System.out.println("Lay du lieu so kham that bai" + e);
        }
        return lsSoKham;
    }
    public void insert(SoKhamEntity skE){
        try {

            String sql = "INSERT INTO SoKham (ID_YTA, ID_BN, TinhTrangBenh, ID_Khoa, ID_BS, ChiDinh, ToaThuoc, ChuanDoan, NgayKham, NgayHenKhamLai, GhiChu, TrangThai) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, skE.getId_YTa());
            pre.setInt(2, skE.getId_BN());
            pre.setString(3, skE.getTinhTrangBenh());
            pre.setInt(4, skE.getId_Khoa());
            pre.setInt(5, skE.getId_BS());            
            pre.setString(6, skE.getChiDinh());
            pre.setString(7, skE.getToaThuoc()); 
            pre.setString(8, skE.getChuanDoan()); 
            
            pre.setString(9, skE.getNgayKham());
            pre.setString(10, skE.getNgayHenKhamLai());
            pre.setString(11,skE.getGhiChu());
            pre.setString(12, skE.getTrangThai());
            if(pre.executeUpdate() > 0){
                System.out.println("INSERT thanh cong");
            }else{
                System.out.println("INSERT that bai");
            }
        } catch (SQLException e) {
            System.out.println("Them that bai" + e);
        }
    }
    
    public void updatePhieuKham(SoKhamEntity skE){
        try {

            String sql = "UPDATE SoKham SET ID_YTA = ?, ID_BN = ?, TinhTrangBenh = ?, ID_khoa = ?, ID_BS = ? WHERE ID = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, skE.getId_YTa());
            pre.setInt(2, skE.getId_BN());
            pre.setString(3, skE.getTinhTrangBenh());
            pre.setInt(4, skE.getId_Khoa());
            pre.setInt(5, skE.getId_BS());            
            if(pre.executeUpdate() > 0){
                System.out.println("UPDATE thanh cong");
            }else{
                System.out.println("UPDATE that bai");
            }
        } catch (SQLException e) {
            System.out.println("Update that bai" + e);
        }
    }
    public void updateSoKham(SoKhamEntity skE){
       try {

            String sql = "UPDATE SoKham SET ChiDinh = ?,ToaThuoc = ?,ChuanDoan = ?, NgayHenKhamLai = ?,GhiChu = ?,TrangThai = ?  WHERE ID = ?";
            PreparedStatement pre = con.prepareStatement(sql);          
            pre.setString(1, skE.getChiDinh());
            pre.setString(2, skE.getToaThuoc()); 
            pre.setString(3, skE.getChuanDoan()); 
            
//            pre.setString(9, skE.getNgayKham());
            pre.setString(4, skE.getNgayHenKhamLai());
            pre.setString(5,skE.getGhiChu());
            pre.setString(6, skE.getTrangThai());
            pre.setInt(7, skE.getId());
            if(pre.executeUpdate() > 0){
                System.out.println("UPDATE thanh cong");
            }else{
                System.out.println("UPDATE that bai");
            }
        } catch (SQLException e) {
            System.out.println("Update that bai" + e);
        }        
    }
    public void delete(int id){
        try {

            String sql = "DELETE FROM SoKham WHERE ID = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, id);
            if(pre.executeUpdate() > 0){
                System.out.println("Delete thanh cong");
            }else{
                System.out.println("Delete that bai");
            }
        } catch (SQLException e) {
            System.out.println("Delete that bai" + e);
        }
    }
    
    public SoKhamEntity selectByID(int id){
        try {

            String sql = "SELECT * FROM SoKham WHERE ID = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, id);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                SoKhamEntity skE = new SoKhamEntity(resu.getInt("ID"), resu.getInt("ID_YTA"), resu.getInt("ID_BN"), resu.getString("TinhTrangBenh"), resu.getInt("ID_khoa"), resu.getInt("ID_BS"),
                        resu.getString("ChiDinh"),resu.getString("ToaThuoc"), resu.getString("ChuanDoan"), resu.getString("NgayKham"), resu.getString("NgayHenKhamLai"), resu.getString("GhiChu"), resu.getString("TrangThai"));
                return skE;
            }
            
        } catch (SQLException e) {
            System.out.println("SelectByID that bai" + e);
        }
        return null;
    }

    public List<SoKhamEntity>   getAllByNameHistory(String TenBN)  { 
        List<SoKhamEntity> lsk = new ArrayList<>();
            try {
                String sql = "SELECT SoKham.* FROM SoKham INNER JOIN BenhNhan ON SoKham.ID_BN = BenhNhan.ID WHERE BenhNhan.HoTenBN = ?";
                PreparedStatement pr = con.prepareStatement(sql);
                pr.setString(1, TenBN);
                ResultSet resu = pr.executeQuery();
                while(resu.next()){
                SoKhamEntity skE = new SoKhamEntity(resu.getInt("ID"), resu.getInt("ID_YTA"), resu.getInt("ID_BN"), resu.getString("TinhTrangBenh"), resu.getInt("ID_khoa"), resu.getInt("ID_BS"),
                        resu.getString("ChiDinh"),resu.getString("ToaThuoc"), resu.getString("ChuanDoan"), resu.getString("NgayKham"), resu.getString("NgayHenKhamLai"), resu.getString("GhiChu"), resu.getString("TrangThai"));
                    lsk.add(skE);
                }   
                return lsk;
                } catch (SQLException e) {
                    System.out.println("loi getAllByName"+e);
                }

            return null;
        }
    public List<Integer> selectYear(){
        String sql = "SELECT distinct year(NgayKham) year  from SoKham ORDER BY year desc";
        List<Integer> list = new ArrayList<>();
        try {
            PreparedStatement pr = con.prepareStatement(sql);
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                list.add(rs.getInt(1));
            }
        } catch (SQLException e) {
        }
        return list;
    }

   
}
