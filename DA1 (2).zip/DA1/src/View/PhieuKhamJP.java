/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package View;

import Dao.BacSiDao;
import Dao.BenhNhanDao;
import Dao.KhoaDao;

import Dao.SoKhamDao;
import Entity.BacSiEntity;
import Entity.BenhNhanEntity;
import Entity.KhoaEntity;
import Entity.SoKhamEntity;
import Item.Item;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import utils.Auth;

/**
 *
 * @author buiva
 */
public class PhieuKhamJP extends javax.swing.JPanel {
    private SoKhamDao skd = new SoKhamDao();
    private BenhNhanDao bnd = new BenhNhanDao();
    private KhoaDao kd = new KhoaDao();
    private BacSiDao bsd = new BacSiDao();
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private List<KhoaEntity> lk = new ArrayList<>();
    private List<BenhNhanEntity> lbn = new ArrayList<>();
    int row =0;
    /**
     * Creates new form PhieuKhamJP
     */
    public PhieuKhamJP() {
        initComponents();
        fillComboboxKhoa();
        fillTable();
        updateStatus();
        fillCBBBacSiByKhoa();
        updateStatus();
        fillTableBN();
        
    }
    public void fillTableKhoa(List<KhoaEntity> lk){
        String tenKhoa = (String) tblBangPK.getValueAt(row, 4);
        KhoaEntity ke = kd.selectByTen(tenKhoa);
        if(ke != null){
            DefaultTableModel model = (DefaultTableModel) tblBangK.getModel();
            model.setRowCount(0);
            model.addRow(new Object[] {ke.getID(),ke.getTenKhoa(),ke.getViTri()});
        }
        
    }
    public void fillCBBBacSiByKhoa(){
        cbbIDKhoa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Item selectKhoa = (Item) cbbIDKhoa.getSelectedItem();
                if(selectKhoa != null){
                int selectKhoaID = selectKhoa.getId();
                
                DefaultComboBoxModel model = new DefaultComboBoxModel();
                for(BacSiEntity bsE : bsd.getBacSiByKhoa(selectKhoaID)){
                Item item = new Item(bsE.getId(), bsE.getTenBS());
                model.addElement(item);
                }
            cbbIDBS.setModel(model);
                
            }
            }
        });
    }
    public void fillTable(){
        DefaultTableModel model = (DefaultTableModel) tblBangPK.getModel();
        model.setRowCount(0);
        List<SoKhamEntity> lsk = skd.getAllSoKham();
        for(SoKhamEntity skE : lsk){
            BenhNhanEntity bnE = bnd.selectByID(skE.getId_BN());
            KhoaEntity kE = kd.selectByID(skE.getId_Khoa());
            BacSiEntity bsE_Yta = bsd.selectByID(skE.getId_YTa());
            BacSiEntity bsE_BS = bsd.selectByID(skE.getId_BS());
            model.addRow(new Object[] {skE.getId(), bsE_Yta.getTenBS(), bnE.getHoTenBN(), skE.getTinhTrangBenh(),kE.getTenKhoa(),bsE_BS.getTenBS() });
        }
        tblBangPK.setModel(model);
    }

    private void fillComboboxKhoa(){
        DefaultComboBoxModel model = new DefaultComboBoxModel();
        for(KhoaEntity kE: kd.getAllKhoa()){
            Item item = new Item(kE.getID(), kE.getTenKhoa());
            model.addElement(item);
        }
        cbbIDKhoa.setModel(model);
    }    
    public void insert(){
        int option = JOptionPane.showConfirmDialog(this, "Bạn chắc muốn thêm ko?");
        if(option == JOptionPane.YES_NO_OPTION){
        skd.insert(getForm());
        fillTable();            
        }
    }
    public void update(){
         row = tblBangPK.getSelectedRow();
        int id = Integer.parseInt(tblBangPK.getValueAt(row, 0).toString());         
        int option = JOptionPane.showConfirmDialog(this, "Bạn chắc muốn sửa không ?");
        if(option == JOptionPane.YES_NO_OPTION){
            SoKhamEntity skE = getForm();
            skE.setId(id);
            skd.updatePhieuKham(skE);               
            fillTable();            
        }
    }
    public void delete(){
        int row = tblBangPK.getSelectedRow();
        int id = Integer.parseInt(tblBangPK.getValueAt(row, 0).toString());        
        int option = JOptionPane.showConfirmDialog(this, "Bạn chắc xóa không ?");
        if(option == JOptionPane.YES_NO_OPTION){
            skd.delete(id);
            fillTable();            
        }
    }
    public void first(){
        row = 0;
        edit();
    }
    public void prev(){
        if(row > 0){
            row--;
            edit();
        }
    }
    public void next(){
        if(row < tblBangPK.getRowCount() - 1){
            row++;
            edit();
        }
    }
    public void last(){
        row = tblBangPK.getRowCount() - 1;
        edit();
    }
    public void clearForm(){
        cbbIDBS.setSelectedItem(null);
        cbbIDKhoa.setSelectedItem(null);
        txtTenBN.setText("");
        teaTinhTrangBenh.setText("");
        this.row = -1;
        updateStatus();
    }
//    
    public void updateStatus(){
        boolean edit = this.row >= 0;
        boolean first = this.row ==0;
        boolean last = this.row == tblBangPK.getRowCount() -1;
        
        btnThem.setEnabled(!edit);
        btnSua.setEnabled(edit);
        btnXoa.setEnabled(edit);
        
        btnFirst1.setEnabled(edit && !first);
        btnPrev1.setEnabled(edit && !first);
        btnNext1.setEnabled(edit && !last);
        btnLast1.setEnabled(edit && !last);
        
    }
//    
    public SoKhamEntity getForm(){
        BenhNhanEntity bnE = new BenhNhanEntity();
        Item tenBN = new Item(bnE.getID(), bnE.getHoTenBN());
        int idBN =  tenBN.getId();
        Item tenKhoa = (Item) cbbIDKhoa.getSelectedItem();
        Item tenBS = (Item) cbbIDBS.getSelectedItem();
        int ID = 0;
        int YTa = Auth.user.getIdBacSi();

        int idKhoa = tenKhoa.getId() ;
        int idBS =tenBS.getId();
        String rong = "";
        String ngayKham = dateFormat.format(new Date());
        String tinhTrangBenh = teaTinhTrangBenh.getText();
        String trangThai = "Chờ Khám";
        SoKhamEntity skE = new SoKhamEntity(ID, YTa, idBN, tinhTrangBenh, idKhoa, idBS, rong, rong, rong, ngayKham, null, rong, trangThai);
        return skE;
    }
    public void setForm(SoKhamEntity skE){
        KhoaEntity kE = kd.selectByID(skE.getId_Khoa());        
        int idKhoa = kE.getID();
        for (int i = 0; i < cbbIDKhoa.getItemCount(); i++) {
            Object item = cbbIDKhoa.getItemAt(i);
            if (item instanceof Item && ((Item) item).getId() == idKhoa) {
                    cbbIDKhoa.setSelectedIndex(i);
                    break;
                
            }
        } 
        
        BenhNhanEntity bnE = bnd.selectByID(skE.getId_BN());
            txtTenBN.setText(bnE.getHoTenBN());
            cbbIDBS.setSelectedItem(skE.getId_BS());
            teaTinhTrangBenh.setText(skE.getTinhTrangBenh());


            
    }
    public void edit(){
        try {
        int id = (int) tblBangPK.getValueAt(row, 0);  
            SoKhamEntity skE = skd.selectByID(id);
            if(skE != null){
                 setForm(skE);
                 updateStatus();
            }
        } catch (Exception e) {
            System.out.println("Loi" + e);
        }
    }
    public void fillTableBN(){
        DefaultTableModel model = (DefaultTableModel) tblBangBN.getModel();
        model.setRowCount(0);
        for(BenhNhanEntity bnE : bnd.getAll()){
                model.addRow(new Object[] {bnE.getID(),bnE.getHoTenBN(),bnE.getSDT()});            
        }
        tblBangBN.setModel(model);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        btnMoi = new javax.swing.JButton();
        cbbIDKhoa = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        teaTinhTrangBenh = new javax.swing.JTextArea();
        jLabel8 = new javax.swing.JLabel();
        cbbIDBS = new javax.swing.JComboBox<>();
        txtTenBN = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBangPK = new javax.swing.JTable();
        btnFirst = new javax.swing.JButton();
        btnPrev = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnFirst1 = new javax.swing.JButton();
        btnPrev1 = new javax.swing.JButton();
        btnNext1 = new javax.swing.JButton();
        btnLast1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblBangK = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        tblBangBN = new javax.swing.JTable();
        txtTimTenBN = new javax.swing.JTextField();
        btnThemBN = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel2.setText("Tên BN");

        jLabel6.setText("Tình trạng bệnh");

        btnThem.setText("Thêm");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setText("Sửa");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnXoa.setText("Xoá");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        btnMoi.setText("Mới");
        btnMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoiActionPerformed(evt);
            }
        });

        jLabel7.setText("Tên khoa");

        teaTinhTrangBenh.setColumns(20);
        teaTinhTrangBenh.setRows(5);
        jScrollPane3.setViewportView(teaTinhTrangBenh);

        jLabel8.setText("Tên BS");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnThem)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                        .addComponent(btnSua)
                        .addGap(36, 36, 36)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(200, 200, 200)
                                .addComponent(btnMoi)
                                .addContainerGap(71, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(btnXoa)
                                .addGap(168, 168, 168))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 397, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jLabel2)
                                .addGap(29, 29, 29)
                                .addComponent(txtTenBN, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(16, 16, 16)
                                        .addComponent(jLabel8)
                                        .addGap(32, 32, 32)
                                        .addComponent(cbbIDBS, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addGap(18, 18, 18)
                                        .addComponent(cbbIDKhoa, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(21, 21, 21))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(35, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbbIDKhoa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel2)
                    .addComponent(txtTenBN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbbIDBS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(54, 54, 54)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThem)
                    .addComponent(btnSua)
                    .addComponent(btnXoa)
                    .addComponent(btnMoi))
                .addGap(50, 50, 50))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        tblBangPK.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID Sổ khám", "Tên Y tá", "Tên BN", "Tình trạng bệnh", "ID Khoa", "Tên BS "
            }
        ));
        tblBangPK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblBangPKMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblBangPK);
        if (tblBangPK.getColumnModel().getColumnCount() > 0) {
            tblBangPK.getColumnModel().getColumn(3).setResizable(false);
        }

        btnFirst.setText("|<");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        btnPrev.setText("<<");
        btnPrev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevActionPerformed(evt);
            }
        });

        btnNext.setText(">>");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnLast.setText(">|");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        btnFirst1.setText("|<");
        btnFirst1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirst1ActionPerformed(evt);
            }
        });

        btnPrev1.setText("<<");
        btnPrev1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrev1ActionPerformed(evt);
            }
        });

        btnNext1.setText(">>");
        btnNext1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNext1ActionPerformed(evt);
            }
        });

        btnLast1.setText(">|");
        btnLast1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLast1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnFirst)
                .addGap(26, 26, 26)
                .addComponent(btnPrev)
                .addGap(32, 32, 32)
                .addComponent(btnNext)
                .addGap(26, 26, 26)
                .addComponent(btnLast)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnFirst1)
                        .addGap(26, 26, 26)
                        .addComponent(btnPrev1)
                        .addGap(32, 32, 32)
                        .addComponent(btnNext1)
                        .addGap(26, 26, 26)
                        .addComponent(btnLast1))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1056, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFirst1)
                    .addComponent(btnPrev1)
                    .addComponent(btnNext1)
                    .addComponent(btnLast1))
                .addGap(70, 70, 70)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFirst)
                    .addComponent(btnPrev)
                    .addComponent(btnNext)
                    .addComponent(btnLast))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        jLabel1.setText("QUẢN LÝ PHIẾU KHÁM");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        tblBangK.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Mã Khoa", "Tên Khoa", "Vị trí"
            }
        ));
        jScrollPane4.setViewportView(tblBangK);

        tblBangBN.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID BN", "Tên Bệnh nhân", "SDT"
            }
        ));
        tblBangBN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblBangBNMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tblBangBN);

        txtTimTenBN.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimTenBNKeyReleased(evt);
            }
        });

        btnThemBN.setText("+");
        btnThemBN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemBNActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap(16, Short.MAX_VALUE)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(90, 90, 90)
                                .addComponent(txtTimTenBN, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnThemBN)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTimTenBN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnThemBN))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(104, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(58, 58, 58))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(399, 399, 399))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(78, 78, 78))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        insert();
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        update();
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        delete();
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoiActionPerformed
        clearForm();
    }//GEN-LAST:event_btnMoiActionPerformed

    private void tblBangPKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBangPKMouseClicked
        row = tblBangPK.getSelectedRow();
        edit();
        KhoaEntity kE = new KhoaEntity();
        kE.setTenKhoa((String) tblBangPK.getValueAt(row, 4));
        lk.add(kE);
        fillTableKhoa(lk);
        
        
    }//GEN-LAST:event_tblBangPKMouseClicked

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        first();
    }//GEN-LAST:event_btnFirstActionPerformed

    private void btnPrevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevActionPerformed
        prev();
    }//GEN-LAST:event_btnPrevActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        next();
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        last();
    }//GEN-LAST:event_btnLastActionPerformed

    private void btnFirst1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirst1ActionPerformed
        first();
    }//GEN-LAST:event_btnFirst1ActionPerformed

    private void btnPrev1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrev1ActionPerformed
        prev();
    }//GEN-LAST:event_btnPrev1ActionPerformed

    private void btnNext1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNext1ActionPerformed
        next();
    }//GEN-LAST:event_btnNext1ActionPerformed

    private void btnLast1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLast1ActionPerformed
        last();
    }//GEN-LAST:event_btnLast1ActionPerformed

    private void btnThemBNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemBNActionPerformed
        ThemBN bn = new ThemBN();
        bn.setVisible(true);
    }//GEN-LAST:event_btnThemBNActionPerformed

    private void txtTimTenBNKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimTenBNKeyReleased
        try {
            DefaultTableModel model = new DefaultTableModel();
            lbn = bnd.search("%" + txtTimTenBN.getText() + "%", "%" + txtTimTenBN.getText() + "%");
            model.addColumn("ID BN");
            model.addColumn("Tên BN");
            model.addColumn("SDT");
            
            for(BenhNhanEntity bnE : lbn){
                model.addRow(new Object[] {bnE.getID(),bnE.getHoTenBN(),bnE.getSDT()});
            }
            tblBangBN.setModel(model);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_txtTimTenBNKeyReleased

    private void tblBangBNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBangBNMouseClicked
        row = tblBangBN.getSelectedRow();
        txtTenBN.setText(tblBangBN.getValueAt(row, 1).toString());
        txtTenBN.setToolTipText(tblBangBN.getValueAt(row, 0).toString());
    }//GEN-LAST:event_tblBangBNMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnFirst1;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnLast1;
    private javax.swing.JButton btnMoi;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnNext1;
    private javax.swing.JButton btnPrev;
    private javax.swing.JButton btnPrev1;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnThemBN;
    private javax.swing.JButton btnXoa;
    private javax.swing.JComboBox<String> cbbIDBS;
    private javax.swing.JComboBox<String> cbbIDKhoa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable tblBangBN;
    private javax.swing.JTable tblBangK;
    private javax.swing.JTable tblBangPK;
    private javax.swing.JTextArea teaTinhTrangBenh;
    private javax.swing.JTextField txtTenBN;
    private javax.swing.JTextField txtTimTenBN;
    // End of variables declaration//GEN-END:variables
}
