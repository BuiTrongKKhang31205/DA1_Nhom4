/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Entity.BacSiEntity;
import dao.Database;
import java.util.*;
import java.sql.*;
/**
 *
 * @author buitr
 */
public class BacSiDao {
    Connection con = Database.getConnection();
    public List<BacSiEntity> getAllBacSi(){
        List<BacSiEntity> listBS = new ArrayList<>();
        try {

            String sql = "SELECT * FROM BACSI ";
            PreparedStatement pre = con.prepareStatement(sql);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                BacSiEntity bsE = new BacSiEntity(resu.getString("MaBS"), resu.getString("TenBS"), resu.getInt("Id_Khoa"),resu.getInt("NamSinh"),
                        resu.getBoolean("ChucVu"),resu.getString("DiaChi"),resu.getString("SDT"),resu.getBoolean("gioiTinh"));
                
                listBS.add(bsE);
            }
        } catch (SQLException e) {
            System.out.println("Lay du lieu Bac Si that bai" + e);
        }
        return listBS;
    }
    public void add(BacSiEntity bs){
        try {

            String sql = "INSERT INTO BacSi (ID_Khoa,TenBS,ChucVu,DiaChi,NamSinh,SDT,GioiTinh) VALUES(?,?,?,?,?,?,?)";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(2, bs.getTenBS());
            pre.setInt(1, bs.getIdKhoa());
            pre.setBoolean(3, bs.isChucVu());
            pre.setInt(5, bs.getNamSinh());
            pre.setString(4, bs.getDiaChi());            
            pre.setString(6, bs.getSDT());
            pre.setBoolean(7, bs.isGioiTinh());
            
            if(pre.executeUpdate() > 0){
                System.out.println("INSERT thanh cong");
            }else{
                System.out.println("INSERT that bai");
            }
        } catch (SQLException e) {
            System.out.println("Them bac si that bai" + e);
        }
    }
    public void update(BacSiEntity bs){
        try {

            String sql = "UPDATE BACSI SET ID_Khoa = ?, TenBS = ?,ChucVu = ?, DiaChi = ?,NamSinh = ? SDT = ?, GioiTinh = ?, WHERE MaBS = ?";
            PreparedStatement pre = con.prepareStatement(sql);            
            pre.setString(1, bs.getTenBS());
            pre.setInt(2, bs.getIdKhoa());
            pre.setInt(3, bs.getNamSinh());
            pre.setString(4, bs.getDiaChi());            
            pre.setString(5, bs.getSDT());
            pre.setBoolean(6, bs.isGioiTinh());
            pre.setString(7, bs.getMaBS());
            
            if(pre.executeUpdate() > 0){
                System.out.println("UPDATE thanh cong");
            }else{
                System.out.println("UPDATE that bai");
            }
        } catch (SQLException e) {
            System.out.println("Cap nhat bac si that bai" + e);
        }
    }
    public void delete(String  maBS){
        try {

            String sql = "DELETE FROM BACSI WHERE MaBS = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, maBS);
            if(pre.executeUpdate() > 0){
                System.out.println("Delete thanh cong");
            }else{
                System.out.println("Delete that bai");
            }
        } catch (SQLException e) {
            System.out.println("Delete that bai" + e);
        }
    }
    public BacSiEntity selectByID(String BacSi){
        try {

            String sql = "SELECT * FROM BACSI WHERE MaBS = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, BacSi);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                BacSiEntity bsE = new BacSiEntity(resu.getString("MaBS"), resu.getString("TenBS"), resu.getInt("Id_Khoa"),resu.getInt("NamSinh"),
                        resu.getBoolean("ChucVu"),resu.getString("DiaChi"),resu.getString("SDT"),resu.getBoolean("gioiTinh"));
                return bsE;
            }
            
        } catch (SQLException e) {
            System.out.println("SelectByID that bai" + e);
        }
        return null;
    }
}
