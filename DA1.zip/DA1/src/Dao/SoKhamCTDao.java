/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Entity.BenhNhanEntity;
import Entity.SoKhamCTEntity;
import dao.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author buitr
 */
public class SoKhamCTDao {
    Connection con = Database.getConnection();
    public List<SoKhamCTEntity> getAll(){
        List<SoKhamCTEntity> lskct = new ArrayList<>();
        try {
            String sql = "select * from SoKhamChiTiet";
            PreparedStatement pr = con.prepareStatement(sql);
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                SoKhamCTEntity skct = new SoKhamCTEntity(rs.getString("MaSoKhamCT"), rs.getInt("ID_BS"), rs.getInt("ID_SoKham"),
                        rs.getString("ToaThuoc"), rs.getString("ChuanDoan"), rs.getString("NgayKham"),rs.getString("NgayHenKhamLai"),
                        rs.getString("GhiChu"));
                lskct.add(skct);
            }
        } catch (SQLException e) {
            System.out.println("Loi lay du lieu" + e);
        }
        return lskct;
    }
    public void insert(SoKhamCTEntity skE){
        try {
            String sql = "INSERT INTO SoKhamChiTiet (MaSoKhamCT, ID_BS, ID_SoKham, ToaThuoc, ChuanDoan, "
                    + "NgayKham, NgayHenKhamLai, GhiChu) VALUES (?,?,?,?,?,?,?,?)";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1, skE.getMaSoKhamCT());
            pr.setInt(2, skE.getId_BS());
            pr.setInt(3, skE.getId_SoKham());
            pr.setString(4, skE.getToaThuoc());
            pr.setString(5, skE.getChuanDoan());
            pr.setString(6, skE.getNgayKham());
            pr.setString(7, skE.getNgayHenKhamLai());
            pr.setString(8, skE.getGhiChu());
            if(pr.executeUpdate() > 0){
                System.out.println("insert thanh cong");
            }else {
                System.out.println("insert that bai");
            }
        } catch (SQLException e) {
            System.out.println("loi them " + e);
        }
    }
    public void update(SoKhamCTEntity skE){
        try {
            String sql = "UPDATE SoKhamChiTiet set ID_BS = ?, ID_SoKham = ?, ToaThuoc = ?, ChuanDoan = ?, NgayKham = ? "
                    + "NgayHenKhamLai = ?, GhiChu = ? WHERE MaSoKhamCT = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(8, skE.getMaSoKhamCT());
            pr.setInt(1, skE.getId_BS());
            pr.setInt(2, skE.getId_SoKham());
            pr.setString(3, skE.getToaThuoc());
            pr.setString(4, skE.getChuanDoan());
            pr.setString(5, skE.getNgayKham());
            pr.setString(6, skE.getNgayHenKhamLai());
            pr.setString(7, skE.getGhiChu());
            if(pr.executeUpdate() > 0){
                System.out.println("update thanh cong");
            }else {
                System.out.println("update that bai");
            }
        } catch (SQLException e) {
            System.out.println("loi sua " + e);
        }
    }
    public void delete(SoKhamCTEntity skE){
        try {
            String sql = "DELETE FROM SoKhamChiTiet WHERE MaSoKhamCT = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1, skE.getMaSoKhamCT());
            if(pr.executeUpdate() > 0){
                System.out.println("delete thanh cong");
            }else {
                System.out.println("delete that bai");
            }
        } catch (SQLException e) {
            System.out.println("loi xoa " + e);
        }
    }
    public SoKhamCTEntity selectByID(String maSoKhamCT){
        try {
            String sql = "SELECT * FROM SoKhamChiTiet WHERE MaSoKhamCT = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1, maSoKhamCT);
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                SoKhamCTEntity skct = new SoKhamCTEntity(rs.getString("MaSoKhamCT"), rs.getInt("ID_BS"), rs.getInt("ID_SoKham"),
                        rs.getString("ToaThuoc"), rs.getString("ChuanDoan"), rs.getString("NgayKham"),rs.getString("NgayHenKhamLai"),
                        rs.getString("GhiChu"));
                return skct;
            }            
        } catch (SQLException e) {
            System.out.println("loi tim" + e);
        }
        return null;
    }    
}
