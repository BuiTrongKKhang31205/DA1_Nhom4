package Dao;

import Entity.TaiKhoanEntity;
import dao.Database;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TaiKhoanDao {
    Connection con = Database.getConnection();
    public List<TaiKhoanEntity> getAll(){
        List<TaiKhoanEntity> listTK = new ArrayList<>();
        try {

            String sql = "SELECT * FROM TaiKhoan ";
            PreparedStatement pre = con.prepareStatement(sql);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                TaiKhoanEntity tkE = new TaiKhoanEntity(resu.getInt("ID"), resu.getInt("ID_BS"), resu.getString("TaiKhoan"),resu.getString("MatKhau"),resu.getBoolean("VaiTro"));                
                listTK.add(tkE);
            }
        } catch (SQLException e) {
            System.out.println("Lay du lieu TaiKhoan that bai" + e);
        }
        return listTK;
    }
    public void add(TaiKhoanEntity tkE){
        try {

            String sql = "INSERT INTO TaiKhoan (ID_BS, TaiKhoan, MatKhau, VaiTro) VALUES(?,?,?,?)";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, tkE.getIdBacSi());
            pre.setString(2, tkE.getTaiKhoan());
            pre.setString(3, tkE.getMatKhau());
            pre.setBoolean(4, tkE.isVaiTro());            

            
            if(pre.executeUpdate() > 0){
                System.out.println("INSERT thanh cong");
            }else{
                System.out.println("INSERT that bai");
            }
        } catch (SQLException e) {
            System.out.println("Them TaiKhoan that bai" + e);
        }
    }
    public void update(TaiKhoanEntity tkE){
        try {

            String sql = "UPDATE TaiKhoan SET ID_BS = ?, TaiKhoan = ?, MatKhau = ?, VaiTro = ? WHERE ID = ?";
            PreparedStatement pre = con.prepareStatement(sql);  
            pre.setInt(1, tkE.getIdBacSi());
            pre.setString(2, tkE.getTaiKhoan());
            pre.setString(3, tkE.getMatKhau());
            pre.setBoolean(4, tkE.isVaiTro());   
            pre.setInt(5, tkE.getID());
            
            if(pre.executeUpdate() > 0){
                System.out.println("UPDATE thanh cong");
            }else{
                System.out.println("UPDATE that bai");
            }
        } catch (SQLException e) {
            System.out.println("Cap nhat tai khoan that bai" + e);
        }
    }
    public void delete(int  id){
        try {

            String sql = "DELETE FROM TaiKhoan WHERE ID = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, id);
            if(pre.executeUpdate() > 0){
                System.out.println("Delete thanh cong");
            }else{
                System.out.println("Delete that bai");
            }
        } catch (SQLException e) {
            System.out.println("Delete that bai" + e);
        }
    }    
    public TaiKhoanEntity selectByTK(String TaiKhoan){
        try {

            String sql = "SELECT * FROM TaiKhoan WHERE TaiKhoan = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, TaiKhoan);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                TaiKhoanEntity tkE = new TaiKhoanEntity(resu.getInt("ID"),  resu.getInt("ID_BS"), resu.getString("TaiKhoan"), resu.getString("MatKhau"),resu.getBoolean("VaiTro"));
                return tkE;
            }
            
        } catch (SQLException e) {
            System.out.println("SelectByID that bai" + e);
        }
        return null;
    }
    public TaiKhoanEntity selectByID(int id){
        try {

            String sql = "SELECT * FROM TaiKhoan WHERE ID = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, id);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                TaiKhoanEntity tkE = new TaiKhoanEntity(resu.getInt("ID"),  resu.getInt("ID_BS"), resu.getString("TaiKhoan"), resu.getString("MatKhau"),resu.getBoolean("VaiTro"));
                return tkE;
            }
            
        } catch (SQLException e) {
            System.out.println("SelectByID that bai" + e);
        }
        return null;
    }    
}
