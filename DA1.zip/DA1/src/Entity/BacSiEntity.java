/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

/**
 *
 * @author buitr
 */
public class BacSiEntity {

    private String maBS, tenBS;
    private int idKhoa, namSinh;
    private boolean chucVu;
    private String diaChi, SDT;
    private boolean gioiTinh;

    public BacSiEntity() {
    }

    public BacSiEntity(String maBS, String tenBS, int idKhoa, int namSinh, boolean chucVu, String diaChi, String SDT, boolean gioiTinh) {
        this.maBS = maBS;
        this.tenBS = tenBS;
        this.idKhoa = idKhoa;
        this.namSinh = namSinh;
        this.chucVu = chucVu;
        this.diaChi = diaChi;
        this.SDT = SDT;
        this.gioiTinh = gioiTinh;
    }

    public String getMaBS() {
        return maBS;
    }

    public void setMaBS(String maBS) {
        this.maBS = maBS;
    }

    public String getTenBS() {
        return tenBS;
    }

    public void setTenBS(String tenBS) {
        this.tenBS = tenBS;
    }

    public int getIdKhoa() {
        return idKhoa;
    }

    public void setIdKhoa(int idKhoa) {
        this.idKhoa = idKhoa;
    }

    public int getNamSinh() {
        return namSinh;
    }

    public void setNamSinh(int namSinh) {
        this.namSinh = namSinh;
    }

    public boolean isChucVu() {
        return chucVu;
    }

    public void setChucVu(boolean chucVu) {
        this.chucVu = chucVu;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

    public boolean isGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(boolean gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    
}
