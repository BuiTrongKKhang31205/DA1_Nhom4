/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

/**
 *
 * @author buitr
 */
public class BenhNhanEntity {
    int ID;
    String hoTenBN,diaChi;
    boolean gioiTinh;
    String SDT,ngaySinh;

    public BenhNhanEntity() {
    }

    public BenhNhanEntity(int ID, String hoTenBN, String diaChi, boolean gioiTinh, String SDT, String ngaySinh) {
        this.ID = ID;
        this.hoTenBN = hoTenBN;
        this.diaChi = diaChi;
        this.gioiTinh = gioiTinh;
        this.SDT = SDT;
        this.ngaySinh = ngaySinh;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getHoTenBN() {
        return hoTenBN;
    }

    public void setHoTenBN(String hoTenBN) {
        this.hoTenBN = hoTenBN;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public boolean isGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(boolean gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

    public String getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(String ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    


}
