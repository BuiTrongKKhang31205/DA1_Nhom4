package Entity;

public class KhoaEntity {

    private String maKhoa, tenKhoa, viTri;

    public KhoaEntity() {
    }

    public KhoaEntity(String maKhoa, String tenKhoa, String viTri) {
        this.maKhoa = maKhoa;
        this.tenKhoa = tenKhoa;
        this.viTri = viTri;
    }

    public String getMaKhoa() {
        return maKhoa;
    }

    public void setMaKhoa(String maKhoa) {
        this.maKhoa = maKhoa;
    }

    public String getTenKhoa() {
        return tenKhoa;
    }

    public void setTenKhoa(String tenKhoa) {
        this.tenKhoa = tenKhoa;
    }

    public String getViTri() {
        return viTri;
    }

    public void setViTri(String viTri) {
        this.viTri = viTri;
    }

}
