/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

/**
 *
 * @author buiva
 */
public class PhieuKhamEntity {
    private int ID,ID_BN,ID_Khoa;
    private String tinhTrangBenh;

    public PhieuKhamEntity() {
    }

    public PhieuKhamEntity(int ID, int ID_BN, int ID_Khoa, String tinhTrangBenh) {
        this.ID = ID;
        this.ID_BN = ID_BN;
        this.ID_Khoa = ID_Khoa;
        this.tinhTrangBenh = tinhTrangBenh;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getID_BN() {
        return ID_BN;
    }

    public void setID_BN(int ID_BN) {
        this.ID_BN = ID_BN;
    }

    public int getID_Khoa() {
        return ID_Khoa;
    }

    public void setID_Khoa(int ID_Khoa) {
        this.ID_Khoa = ID_Khoa;
    }

    public String getTinhTrangBenh() {
        return tinhTrangBenh;
    }

    public void setTinhTrangBenh(String tinhTrangBenh) {
        this.tinhTrangBenh = tinhTrangBenh;
    }
    
}
