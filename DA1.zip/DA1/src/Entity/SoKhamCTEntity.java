package Entity;

public class SoKhamCTEntity {
    String maSoKhamCT;
    int id_BS,id_SoKham;
    String toaThuoc,chuanDoan,ngayKham,ngayHenKhamLai,ghiChu;

    public SoKhamCTEntity() {
    }

    public SoKhamCTEntity(String maSoKhamCT, int id_BS, int id_SoKham, String toaThuoc, String chuanDoan, String ngayKham, String ngayHenKhamLai, String ghiChu) {
        this.maSoKhamCT = maSoKhamCT;
        this.id_BS = id_BS;
        this.id_SoKham = id_SoKham;
        this.toaThuoc = toaThuoc;
        this.chuanDoan = chuanDoan;
        this.ngayKham = ngayKham;
        this.ngayHenKhamLai = ngayHenKhamLai;
        this.ghiChu = ghiChu;
    }

    public String getMaSoKhamCT() {
        return maSoKhamCT;
    }

    public void setMaSoKhamCT(String maSoKhamCT) {
        this.maSoKhamCT = maSoKhamCT;
    }

    public int getId_BS() {
        return id_BS;
    }

    public void setId_BS(int id_BS) {
        this.id_BS = id_BS;
    }

    public int getId_SoKham() {
        return id_SoKham;
    }

    public void setId_SoKham(int id_SoKham) {
        this.id_SoKham = id_SoKham;
    }

    public String getToaThuoc() {
        return toaThuoc;
    }

    public void setToaThuoc(String toaThuoc) {
        this.toaThuoc = toaThuoc;
    }

    public String getChuanDoan() {
        return chuanDoan;
    }

    public void setChuanDoan(String chuanDoan) {
        this.chuanDoan = chuanDoan;
    }

    public String getNgayKham() {
        return ngayKham;
    }

    public void setNgayKham(String ngayKham) {
        this.ngayKham = ngayKham;
    }

    public String getNgayHenKhamLai() {
        return ngayHenKhamLai;
    }

    public void setNgayHenKhamLai(String ngayHenKhamLai) {
        this.ngayHenKhamLai = ngayHenKhamLai;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }
    
}
