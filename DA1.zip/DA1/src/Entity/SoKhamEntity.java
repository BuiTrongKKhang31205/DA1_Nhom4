package Entity;

public class SoKhamEntity {
    
    private int id, id_YTa, id_BN;
    private String tinhTrangBenh;
    private int id_Khoa,id_BS;
    private String chiDinh,toaThuoc, chuanDoan, ngayKham, ngayHenKhamLai, ghiChu;
    private boolean trangThai;

    public SoKhamEntity() {
    }

    public SoKhamEntity(int id, int id_YTa, int id_BN, String tinhTrangBenh, int id_Khoa, int id_BS, String chiDinh, String toaThuoc, String chuanDoan, String ngayKham, String ngayHenKhamLai, String ghiChu, boolean trangThai) {
        this.id = id;
        this.id_YTa = id_YTa;
        this.id_BN = id_BN;
        this.tinhTrangBenh = tinhTrangBenh;
        this.id_Khoa = id_Khoa;
        this.id_BS = id_BS;
        this.chiDinh = chiDinh;
        this.toaThuoc = toaThuoc;
        this.chuanDoan = chuanDoan;
        this.ngayKham = ngayKham;
        this.ngayHenKhamLai = ngayHenKhamLai;
        this.ghiChu = ghiChu;
        this.trangThai = trangThai;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_YTa() {
        return id_YTa;
    }

    public void setId_YTa(int id_YTa) {
        this.id_YTa = id_YTa;
    }

    public int getId_BN() {
        return id_BN;
    }

    public void setId_BN(int id_BN) {
        this.id_BN = id_BN;
    }

    public String getTinhTrangBenh() {
        return tinhTrangBenh;
    }

    public void setTinhTrangBenh(String tinhTrangBenh) {
        this.tinhTrangBenh = tinhTrangBenh;
    }

    public int getId_Khoa() {
        return id_Khoa;
    }

    public void setId_Khoa(int id_Khoa) {
        this.id_Khoa = id_Khoa;
    }

    public int getId_BS() {
        return id_BS;
    }

    public void setId_BS(int id_BS) {
        this.id_BS = id_BS;
    }

    public String getChiDinh() {
        return chiDinh;
    }

    public void setChiDinh(String chiDinh) {
        this.chiDinh = chiDinh;
    }

    public String getToaThuoc() {
        return toaThuoc;
    }

    public void setToaThuoc(String toaThuoc) {
        this.toaThuoc = toaThuoc;
    }

    public String getChuanDoan() {
        return chuanDoan;
    }

    public void setChuanDoan(String chuanDoan) {
        this.chuanDoan = chuanDoan;
    }

    public String getNgayKham() {
        return ngayKham;
    }

    public void setNgayKham(String ngayKham) {
        this.ngayKham = ngayKham;
    }

    public String getNgayHenKhamLai() {
        return ngayHenKhamLai;
    }

    public void setNgayHenKhamLai(String ngayHenKhamLai) {
        this.ngayHenKhamLai = ngayHenKhamLai;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    public boolean isTrangThai() {
        return trangThai;
    }

    public void setTrangThai(boolean trangThai) {
        this.trangThai = trangThai;
    }


    
    
}
