package Entity;

public class TaiKhoanEntity {
    private int ID_BS;
    private String TaiKhoan, MatKhau;
    private boolean vaiTro;

    public TaiKhoanEntity() {
    }

    public TaiKhoanEntity(int ID_BS, String TaiKhoan, String MatKhau, boolean vaiTro) {
        this.ID_BS = ID_BS;
        this.TaiKhoan = TaiKhoan;
        this.MatKhau = MatKhau;
        this.vaiTro = vaiTro;
    }

    public int getID_BS() {
        return ID_BS;
    }

    public void setID_BS(int ID_BS) {
        this.ID_BS = ID_BS;
    }

    public String getTaiKhoan() {
        return TaiKhoan;
    }

    public void setTaiKhoan(String TaiKhoan) {
        this.TaiKhoan = TaiKhoan;
    }

    public String getMatKhau() {
        return MatKhau;
    }

    public void setMatKhau(String MatKhau) {
        this.MatKhau = MatKhau;
    }

    public boolean isVaiTro() {
        return vaiTro;
    }

    public void setVaiTro(boolean vaiTro) {
        this.vaiTro = vaiTro;
    }


    
    
}
