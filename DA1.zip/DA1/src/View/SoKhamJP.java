/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package View;

import Dao.BacSiDao;
import Dao.BenhNhanDao;
import Dao.KhoaDao;
import Dao.SoKhamDao;
import Entity.BacSiEntity;
import Entity.BenhNhanEntity;
import Entity.KhoaEntity;
import Entity.SoKhamEntity;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import utils.Auth;
import viewModels.SoKhamViewModel;



/**
 *
 * @author buiva
 */
public class SoKhamJP extends javax.swing.JPanel {
    private BenhNhanDao bnd = new BenhNhanDao();
    private SoKhamDao skd = new SoKhamDao();
    private BacSiDao bsd = new BacSiDao();
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private List<BenhNhanEntity> lbn = new ArrayList<>();
    private List<BacSiEntity> lbs = new ArrayList<>();
    private KhoaDao kd = new KhoaDao();
    private SoKhamEntity skE = new SoKhamEntity();

    int row = 0;
    public SoKhamJP() {
        initComponents();
        
        fillTableBSToDay();
        updateStatus();
        Seach();
        EventButton();
        lblToday.setText("Sổ khám chờ ngày: " + dateFormat.format(new Date()));
    }
    public void Seach(){
        btnTimKiem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = txtTimKiem.getText();
                List<SoKhamEntity> lsk = null;
                try {
                    if(name.trim().length()==0){
                        lsk =  skd.getAllSoKham();
                    }else{
                        lsk = skd.getAllByName(name);
                    }
                } catch (Exception e1) {
                    System.out.println("loi tim kiem"+e1);
                }
                SoKhamViewModel model = new SoKhamViewModel(lsk);
                tblBangSK.setModel(model);
            }
        }); 
    }
    public void fillTableBN(List<BenhNhanEntity> lbn) {
        String tenBN =  (String) tblBangSK.getValueAt(row, 2);
        BenhNhanEntity bnEntity = bnd.selectByTen(tenBN);
        if (bnEntity != null) {
            DefaultTableModel model = (DefaultTableModel) tblBangBN.getModel();
            model.setRowCount(0);
            model.addRow(new Object[]{bnEntity.getID(), bnEntity.getHoTenBN(), bnEntity.getNgaySinh(), bnEntity.isGioiTinh() ? "Nữ" : "Nam"});
        }
    }
    public void fillTableBS(List<BacSiEntity> lbs){
        String tenBS =  (String) tblBangSK.getValueAt(row, 5);
        BacSiEntity bsEntity = bsd.selectByTen(tenBS);
        if(bsEntity != null){
            DefaultTableModel model = (DefaultTableModel) tblBangBS.getModel();
            model.setRowCount(0);
            KhoaEntity kE = kd.selectByID(bsEntity.getIdKhoa());
            model.addRow(new Object[] {bsEntity.getId(),bsEntity.getTenBS(),kE.getTenKhoa()});
        }
    }
    
    public void EventButton(){
        jrHienThi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(jrHienThi.isSelected()){
                    fillTable();
                }else{
                    fillTableBSToDay();
            }
            
        }
    });
                }
    public void fillTableBSToDay(){
        DefaultTableModel model = (DefaultTableModel) tblBangSK.getModel();
        model.setRowCount(0);
        for(SoKhamEntity skE : skd.getAllSoKham()){
            if(skE.getId_BS() == Auth.user.getIdBacSi() && skE.getNgayKham().equals(dateFormat.format(new Date()))){
            BenhNhanEntity bnE = bnd.selectByID(skE.getId_BN());
            BacSiEntity bsE_Yta = bsd.selectByID(skE.getId_YTa());
            BacSiEntity bsE_BS = bsd.selectByID(skE.getId_BS());
            
            
            KhoaEntity kE = kd.selectByID(skE.getId_Khoa());
            model.addRow(new Object[] {skE.getId(), bsE_Yta.getTenBS(), bnE.getHoTenBN(), skE.getTinhTrangBenh(),kE.getTenKhoa(),bsE_BS.getTenBS(),
                skE.getChiDinh(), skE.getChuanDoan(),skE.getToaThuoc(),skE.getNgayKham(),skE.getNgayHenKhamLai(),
                skE.getGhiChu(),skE.isTrangThai()?"Chờ khám":"Đang điều trị"});                
            }
        }
        tblBangSK.setModel(model);
    }
    public void fillTable(){
        DefaultTableModel model = (DefaultTableModel) tblBangSK.getModel();
        model.setRowCount(0);
        for(SoKhamEntity skE : skd.getAllSoKham()){
            BenhNhanEntity bnE = bnd.selectByID(skE.getId_BN());
            BacSiEntity bsE_Yta = bsd.selectByID(skE.getId_YTa());
            BacSiEntity bsE_BS = bsd.selectByID(skE.getId_BS());
            KhoaEntity kE = kd.selectByID(skE.getId_Khoa());
            model.addRow(new Object[] {skE.getId(), bsE_Yta.getTenBS(), bnE.getHoTenBN(), skE.getTinhTrangBenh(),kE.getTenKhoa(),bsE_BS.getTenBS(),
                skE.getChiDinh(), skE.getChuanDoan(),skE.getToaThuoc(),skE.getNgayKham(),skE.getNgayHenKhamLai(),
                skE.getGhiChu(),skE.isTrangThai()? "Chờ khám":"Đang điều trị"});                
            }
        
        tblBangSK.setModel(model);        
    }
    

    
    public void update(){
        row = tblBangSK.getSelectedRow();
        int id = (int) tblBangSK.getValueAt(row, 0);
        int option = JOptionPane.showConfirmDialog(this, "Bạn chắc muốn sửa ko?");
        if(option == JOptionPane.YES_NO_OPTION){
            SoKhamEntity skE = getForm();
            skE.setId(id);
            skd.updateSoKham(skE);
            JOptionPane.showMessageDialog(this, "Sua Thanh cong");
            fillTableBSToDay();            
        }        
    }
    
    public void delete(){
        row = tblBangSK.getSelectedRow();
        int id = (int) tblBangSK.getValueAt(row, 0);
        int option = JOptionPane.showConfirmDialog(this, "Bạn chắc xóa ko?");
        if(option == JOptionPane.YES_NO_OPTION){
        skd.delete(id);
        JOptionPane.showMessageDialog(this, "Xoa Thanh cong");
        fillTableBSToDay();            
        }   
    }
    
   public void first(){
        row = 0;
        edit();
    }
   
    public void prev(){
        if(row > 0){
            row--;
            edit();
            
        }
    }
    
    public void next(){
        if(row < tblBangSK.getRowCount() - 1){
            row++;
            edit();
        }
    }
    
    public void last(){
        row = tblBangSK.getRowCount() - 1;
        edit();
    }
    
    public void edit(){
        try {
            int id = (int) tblBangSK.getValueAt(row, 0);
            SoKhamEntity skE = skd.selectByID(id);
            if(skE != null){
                setForm(skE);
                updateStatus();
            }
        } catch (Exception e) {
            System.out.println("loi edit"+e);
        }
    
    }
    
    public void clearForm(){

        teaChuanDoan.setText("");
        teaToaThuoc.setText("");
        teaGhiChu.setText("");
        jdcNgayHenKhamLai.setDate(null);
        jrChoKham.setSelected(true);
        jrDangDT.setSelected(false);
        this.row = -1;
        updateStatus();
        
    }
    
    public SoKhamEntity getForm(){
        int id = 0;
        int idBS = Auth.user.getIdBacSi();
        String chiDinh = teaChiDinh.getText();
        String chuanDoan = teaChuanDoan.getText();
        String toaThuoc = teaToaThuoc.getText();
        String ngayKham = dateFormat.format(new Date());
        String ngayHenKhamLai = dateFormat.format(jdcNgayHenKhamLai.getDate());
        String ghiChu = teaGhiChu.getText();
        boolean trangThai = jrChoKham.isSelected();
        String ttb = skE.getTinhTrangBenh();
       SoKhamEntity skE = new SoKhamEntity(id, 0, 0, ttb, 0, idBS, chiDinh, toaThuoc, chuanDoan, ngayKham, ngayHenKhamLai, ghiChu, trangThai);

        return skE;
    }

    public void setForm(SoKhamEntity skE){
        try {
            teaChiDinh.setText(skE.getChiDinh());
            teaChuanDoan.setText(skE.getChuanDoan());
            teaToaThuoc.setText(skE.getToaThuoc());
            teaGhiChu.setText(skE.getGhiChu());
            
        if (skE.getNgayHenKhamLai() != null) {
            jdcNgayHenKhamLai.setDate(new SimpleDateFormat("yyyy-MM-dd").parse(skE.getNgayHenKhamLai()));
        } else {
            jdcNgayHenKhamLai.setDate(null);
        }
            jrChoKham.setSelected(skE.isTrangThai());            
            jrDangDT.setSelected(!skE.isTrangThai());            
        } catch (Exception e) {
            System.out.println("loi setForm"+e);
        }
    }
    
    public void updateStatus(){
        boolean edit = this.row >=0;
        boolean first = this.row ==0;
        boolean last = this.row == tblBangSK.getRowCount() - 1;
        
        btnSua.setEnabled(edit);
        btnXoa.setEnabled(edit);
        
        btnFirst.setEnabled(edit && !first);
        btnPrev.setEnabled(edit && !first);
        btnNext.setEnabled(edit && !last);
        btnLast.setEnabled(edit && !last);        
        
    }
//    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblBangBN1 = new javax.swing.JTable();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        LichSuKham = new javax.swing.JMenuItem();
        jPanel4 = new javax.swing.JPanel();
        btnPrev = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBangSK = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        txtTimKiem = new javax.swing.JTextField();
        btnTimKiem = new javax.swing.JButton();
        lblToday = new javax.swing.JLabel();
        jrHienThi = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblBangBN = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        btnNew = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        teaGhiChu = new javax.swing.JTextArea();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        teaChuanDoan = new javax.swing.JTextArea();
        jScrollPane5 = new javax.swing.JScrollPane();
        teaToaThuoc = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        jrChoKham = new javax.swing.JRadioButton();
        jrDangDT = new javax.swing.JRadioButton();
        jdcNgayHenKhamLai = new com.toedter.calendar.JDateChooser();
        jScrollPane8 = new javax.swing.JScrollPane();
        teaChiDinh = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblBangBS = new javax.swing.JTable();

        jPanel6.setBackground(new java.awt.Color(204, 204, 204));
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Bệnh nhân"));

        tblBangBN1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID_BN", "Tên Bệnh nhân", "Ngày sinh", "Giới tính"
            }
        ));
        jScrollPane6.setViewportView(tblBangBN1);
        if (tblBangBN1.getColumnModel().getColumnCount() > 0) {
            tblBangBN1.getColumnModel().getColumn(2).setHeaderValue("");
        }

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        LichSuKham.setText("Lịch sử khám");
        LichSuKham.setName("Lịch sử khám"); // NOI18N
        LichSuKham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LichSuKhamActionPerformed(evt);
            }
        });
        jPopupMenu1.add(LichSuKham);

        setBackground(new java.awt.Color(204, 204, 204));

        jPanel4.setBackground(new java.awt.Color(204, 204, 204));
        jPanel4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btnPrev.setText("<<");
        btnPrev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevActionPerformed(evt);
            }
        });

        btnFirst.setText("|<");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        btnLast.setText(">|");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        btnNext.setText(">>");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        tblBangSK.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Tên Y tá", "Tên bệnh nhân", "Tình trạng bệnh", "Tên Khoa", "Tên bác sĩ", "Chỉ định", "Chuẩn đoán", "Toa thuốc", "Ngày khám", "Ngày hẹn khám lại", "Ghi chú", "Trạng thái"
            }
        ));
        tblBangSK.setGridColor(new java.awt.Color(255, 255, 255));
        tblBangSK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblBangSKMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tblBangSKMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tblBangSK);

        jPanel7.setBackground(new java.awt.Color(204, 204, 204));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder("Tìm kiếm"));

        txtTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemActionPerformed(evt);
            }
        });

        btnTimKiem.setText("Tìm kiếm");
        btnTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 569, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addComponent(btnTimKiem)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiem))
                .addGap(0, 11, Short.MAX_VALUE))
        );

        lblToday.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblToday.setText("Sổ khám chờ ngày :    ");

        jrHienThi.setText("Hiện tất cả dữ liệu bảng");
        jrHienThi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrHienThiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(302, 302, 302)
                .addComponent(lblToday, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(929, 929, 929)
                        .addComponent(jrHienThi)
                        .addGap(41, 41, 41)
                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnPrev, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1302, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(lblToday)
                        .addGap(25, 25, 25)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPrev)
                    .addComponent(btnFirst)
                    .addComponent(btnLast)
                    .addComponent(btnNext)
                    .addComponent(jrHienThi))
                .addGap(8, 8, 8))
        );

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Bệnh nhân"));

        tblBangBN.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID_BN", "Tên Bệnh nhân", "Ngày sinh", "Giới tính"
            }
        ));
        jScrollPane3.setViewportView(tblBangBN);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 493, Short.MAX_VALUE)
                .addGap(16, 16, 16))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Thông tin"));

        btnNew.setText("Mới");
        btnNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewActionPerformed(evt);
            }
        });

        jLabel3.setText("Chuẩn đoán");

        jLabel8.setText("Ghi chú");

        teaGhiChu.setColumns(20);
        teaGhiChu.setRows(5);
        jScrollPane2.setViewportView(teaGhiChu);

        btnSua.setText("Sửa");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnXoa.setText("Xóa");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        jLabel4.setText("Ngày hẹn khám lại");

        jLabel6.setText("Toa thuốc");

        jLabel1.setText("Chỉ định");

        teaChuanDoan.setColumns(20);
        teaChuanDoan.setRows(5);
        jScrollPane4.setViewportView(teaChuanDoan);

        teaToaThuoc.setColumns(20);
        teaToaThuoc.setRows(5);
        jScrollPane5.setViewportView(teaToaThuoc);

        jLabel5.setText("Trạng thái");

        buttonGroup1.add(jrChoKham);
        jrChoKham.setText("Chờ khám");

        buttonGroup1.add(jrDangDT);
        jrDangDT.setText("Đang điều trị");

        teaChiDinh.setColumns(20);
        teaChiDinh.setRows(5);
        jScrollPane8.setViewportView(teaChiDinh);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(225, 225, 225)
                        .addComponent(btnSua)
                        .addGap(61, 61, 61)
                        .addComponent(btnXoa)
                        .addGap(55, 55, 55)
                        .addComponent(btnNew)
                        .addContainerGap(144, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel1)
                                .addComponent(jLabel8))
                            .addGap(44, 44, 44)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel5Layout.createSequentialGroup()
                                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel5)
                                        .addGroup(jPanel5Layout.createSequentialGroup()
                                            .addGap(18, 18, 18)
                                            .addComponent(jLabel4))))
                                .addGroup(jPanel5Layout.createSequentialGroup()
                                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(37, 37, 37)
                                    .addComponent(jLabel3)))
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel5Layout.createSequentialGroup()
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                            .addComponent(jrChoKham)
                                            .addGap(65, 65, 65)
                                            .addComponent(jrDangDT))
                                        .addComponent(jdcNgayHenKhamLai, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, Short.MAX_VALUE))))
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 695, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jrChoKham)
                            .addComponent(jrDangDT)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGap(22, 22, 22)
                                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel5Layout.createSequentialGroup()
                                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel3)
                                                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(30, 30, 30)
                                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jdcNgayHenKhamLai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel4)))
                                            .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGap(31, 31, 31)
                                        .addComponent(jLabel1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel6)))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel5)))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(115, 115, 115)
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 10, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNew)
                    .addComponent(btnXoa)
                    .addComponent(btnSua))
                .addContainerGap())
        );

        jLabel10.setFont(new java.awt.Font("Copperplate", 1, 18)); // NOI18N
        jLabel10.setText("Sổ khám ");

        jPanel8.setBackground(new java.awt.Color(204, 204, 204));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Bác sĩ"));

        tblBangBS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID Bác sĩ", "Tên bác sĩ", "Tên khoa"
            }
        ));
        jScrollPane7.setViewportView(tblBangBS);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7)
                .addGap(16, 16, 16))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 1322, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 71, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(41, 41, 41))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(595, 595, 595))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void tblBangSKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBangSKMouseClicked
        row = tblBangSK.getSelectedRow();
        edit();
        BenhNhanEntity bnEntity = new BenhNhanEntity();
        bnEntity.setHoTenBN((String) tblBangSK.getValueAt(row, 2));
        lbn.add(bnEntity);
        fillTableBN(lbn);
        BacSiEntity bsEntity = new BacSiEntity();
        bsEntity.setTenBS((String) tblBangSK.getValueAt(row, 5));
        lbs.add(bsEntity);
        fillTableBS(lbs);
        

    }//GEN-LAST:event_tblBangSKMouseClicked

    private void btnNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewActionPerformed
                clearForm();
    }//GEN-LAST:event_btnNewActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
                update();
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
                delete();
    }//GEN-LAST:event_btnXoaActionPerformed

    private void txtTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimKiemActionPerformed

    private void btnTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnTimKiemActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        first();
    }//GEN-LAST:event_btnFirstActionPerformed

    private void btnPrevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevActionPerformed
        prev();
    }//GEN-LAST:event_btnPrevActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        next();
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        last();
    }//GEN-LAST:event_btnLastActionPerformed

    private void jrHienThiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrHienThiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jrHienThiActionPerformed

    private void tblBangSKMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBangSKMouseReleased
        if(evt.isPopupTrigger()){
            jPopupMenu1.show(tblBangSK,evt.getX(),evt.getY());
            
        }
    }//GEN-LAST:event_tblBangSKMouseReleased

    private void LichSuKhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LichSuKhamActionPerformed
    int selectedRow = tblBangSK.getSelectedRow();
    if (selectedRow != -1) {
        JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
        SoKhamEntity selectedSoKham = skd.getAllSoKham().get(selectedRow); // Lấy thông tin từ dòng đã chọn
//        int id = (int) tblBangSK.getValueAt(row, 2);
//        List<SoKhamEntity> lsk = skd.getPatientHistory(id);
        LichSuKham lichSuKham = new LichSuKham(frame, true,selectedSoKham ); // Truyền thông tin vào JDialog
        lichSuKham.setDefaultCloseOperation(frame.DISPOSE_ON_CLOSE);
        lichSuKham.pack();
        lichSuKham.setLocationRelativeTo(frame);
        lichSuKham.setVisible(true);
    } else {
        JOptionPane.showMessageDialog(null, "Vui lòng chọn một dòng để xem lịch sử khám.");
    }
    }//GEN-LAST:event_LichSuKhamActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem LichSuKham;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNew;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrev;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnTimKiem;
    private javax.swing.JButton btnXoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private com.toedter.calendar.JDateChooser jdcNgayHenKhamLai;
    private javax.swing.JRadioButton jrChoKham;
    private javax.swing.JRadioButton jrDangDT;
    private javax.swing.JRadioButton jrHienThi;
    private javax.swing.JLabel lblToday;
    private javax.swing.JTable tblBangBN;
    private javax.swing.JTable tblBangBN1;
    private javax.swing.JTable tblBangBS;
    private javax.swing.JTable tblBangSK;
    private javax.swing.JTextArea teaChiDinh;
    private javax.swing.JTextArea teaChuanDoan;
    private javax.swing.JTextArea teaGhiChu;
    private javax.swing.JTextArea teaToaThuoc;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables
}
