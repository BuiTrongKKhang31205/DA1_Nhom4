/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import Bean.DanhMucBean;
import View.BacSiJP;
import View.BenhNhanJP;
import View.KhoaJP;
import View.PhieuKhamJP;
import View.SoKhamJP;
import View.TaiKhoanJP;
import View.TrangChuJP;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import utils.Auth;

/**
 *
 * @author buiva
 */
public class ChuyenManHinhController {
    private JPanel root;
    private String kindSelected = "";
    List<DanhMucBean> listItem = null; 
    
    public ChuyenManHinhController(JPanel jpnRoot) {
        this.root = jpnRoot;
    }
    public void setView(JPanel jpnItem, JLabel jlbItem){
        kindSelected = "TrangChu";
        jpnItem.setBackground(new Color(153, 153, 153));
        jlbItem.setBackground(new Color(153, 153, 153));
        root.removeAll();
        root.setLayout(new BorderLayout());
        root.add(new TrangChuJP());
        root.validate();
        root.repaint();
    }
    public void setEvent(List<DanhMucBean> listItem){
        this.listItem = listItem;
        for(DanhMucBean item : listItem){
            item.getJlb().addMouseListener(new LabelEvent(item.getKind(), item.getJpn(), item.getJlb()));
        }    
    }
    class LabelEvent implements MouseListener{
        private JPanel node;
        
        private String kind;
        private JPanel jpnItem;
        private JLabel jlbItem;

        public LabelEvent(String kind, JPanel jpnItem, JLabel jlbItem) {
            this.kind = kind;
            this.jpnItem = jpnItem;
            this.jlbItem = jlbItem;
        }
        
        
        @Override
        public void mouseClicked(MouseEvent e) {
            switch (kind) {
                case "TrangChu":
                    node = new TrangChuJP();
                    break;
                case "BenhNhan":
                    node = new BenhNhanJP();
                    break;
                case "PhieuKham":
                    node = new PhieuKhamJP();
                    break;
                case "BacSi":
                    if(Auth.isManager()){
                        node = new BacSiJP();
                    
                    }else{
                        JOptionPane.showMessageDialog(root, "Bạn không có quyền truy cập");
                    }
                    break;
                case "Khoa":
                    if(Auth.isManager()){
                        node = new KhoaJP();
                        
                    }else{
                        JOptionPane.showMessageDialog(root, "Bạn không có quyền truy cập");
                    } 
                    break;
                case "SoKham":
                    if(Auth.isManager()){
                        node = new SoKhamJP();
                       
                    }else{
                        JOptionPane.showMessageDialog(root, "Bạn không có quyền truy cập");
                    }   
                     break;
                case "TaiKhoan":
                    if(Auth.isManager()){
                        node = new TaiKhoanJP();
                         
                    }else{
                        JOptionPane.showMessageDialog(root, "Bạn không có quyền truy cập");
                    }  
                    break;
                default:
                    break;
            }
            if(node != null){
                root.removeAll();
                root.setLayout(new BorderLayout());
                root.add(node);
                root.validate();
                root.repaint();
                setChangeBackgroud(kind);                
            }

        }

        @Override
        public void mousePressed(MouseEvent e) {
            kindSelected = kind;
            jpnItem.setBackground(new Color(153, 153, 153));
            jlbItem.setBackground(new Color(153, 153, 153));
            
        }

        @Override
        public void mouseReleased(MouseEvent e) {
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            jpnItem.setBackground(new Color(153, 153, 153));
            jlbItem.setBackground(new Color(153, 153, 153));            
        }

        @Override
        public void mouseExited(MouseEvent e) {
            if(!kindSelected.equalsIgnoreCase(kind)){
            jpnItem.setBackground(new Color(242,242,242));
            jlbItem.setBackground(new Color(242,242,242));                 
            }
                
        }
        
    }
    private void setChangeBackgroud(String kind){
        for(DanhMucBean item : listItem){
            if(item.getKind().equalsIgnoreCase(kind)){
                item.getJpn().setBackground(new Color(153, 153, 153));
                item.getJlb().setBackground(new Color(153, 153, 153));              
            }else{
                item.getJpn().setBackground(new Color(242,242,242));
                item.getJlb().setBackground(new Color(242,242,242));                  
            }
        }
    }
}
