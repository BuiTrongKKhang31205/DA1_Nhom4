/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package viewModels;

import Dao.BacSiDao;
import Dao.BenhNhanDao;
import Dao.SoKhamDao;
import Entity.BacSiEntity;
import Entity.BenhNhanEntity;
import Entity.SoKhamEntity;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author buiva
 */
public class SoKhamViewModel extends AbstractTableModel{
    private BenhNhanDao bnd = new BenhNhanDao();
    private BacSiDao bsd = new BacSiDao();
    private static final int ID_COL = 0;
    private static final int ID_BS_COL = 1;   
    private static final int ID_BN_COL = 2;
    private static final int ToaThuoc_COL = 3;
    private static final int ChuanDoan_COL =4;
    private static final int NgayKham_COL = 5;
    private static final int NgayHenKhamLai_COL = 6;
    private static final int GhiChu_COL = 7;
    private static final int TrangThai_COL = 8;
    private String[] columnNames = {"ID Sổ khám", "Tên bác sĩ", "Tên bệnh nhân", "Chuẩn đoán", "Toa thuốc",
    "Ngày khám", "Ngày hẹn khám lại","Ghi chú", "Trạng thái"};
    private List<SoKhamEntity> soKham;
    public SoKhamViewModel (List<SoKhamEntity> lsk){
        this.soKham = lsk;
        
    }
    public String getColumnName(int col){
        return columnNames[col]; 
    }
    public Class getComnClass(int c){
        return getValueAt(0, c).getClass();
    }
    


    @Override
    public int getRowCount() {
        return soKham.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        SoKhamEntity skE = soKham.get(rowIndex);
        
        BenhNhanEntity bnE = bnd.selectByID(skE.getId_BN());
        BacSiEntity bsE =bsd.selectByID(skE.getId_BS());
        switch (columnIndex) {
            case ID_COL:
                return skE.getId();
            case ID_BS_COL:
                return bsE.getTenBS();
            case ID_BN_COL:
                return bnE.getHoTenBN();
            case ToaThuoc_COL:
                return skE.getToaThuoc();
            case ChuanDoan_COL:
                return skE.getChuanDoan();
            case NgayKham_COL:
                return skE.getNgayKham();
            case NgayHenKhamLai_COL:
                return skE.getNgayHenKhamLai();
            case GhiChu_COL:
                return skE.getGhiChu();
            case TrangThai_COL:
                return skE.isTrangThai() ?"Tái khám":"Đang điều trị";                
            default:
                return skE.getId_BN();
        }
        
    }
    
}
