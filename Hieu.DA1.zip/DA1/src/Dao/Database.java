package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author buitr
 */
public class Database {
    private static Connection connection;
    private static final String jdbcUrl = "jdbc:sqlserver://localhost:1436;databaseName=DA1;encrypt=true;trustServerCertificate=true";
    private static final String username = "sa";
    private static final String password = "1Secure*Password1"; // phụ thuộc tài khoản đăng nhập azude
    // Phương thức tạo kết nối
    public static Connection getConnection() {
        if (connection == null) {
            try {
                connection = DriverManager.getConnection(jdbcUrl, username, password);
                System.out.println("KN thanh cong");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }
    public static void main(String[] args) {
        Database.getConnection();
    }
   public static PreparedStatement getStmt(String sql,Object...args)throws SQLException{
       Connection cn = DriverManager.getConnection(jdbcUrl,username,password);
       PreparedStatement pr;
       if(sql.trim().startsWith("{")){
           pr = cn.prepareCall(sql);
       }else{
           pr = cn.prepareStatement(sql);
           
       }
       for(int i=0;i<args.length;i++){
           pr.setObject(i+1, args[i]);
       }
       return pr;
       
   }
   public static int update(String sql,Object...args)throws SQLException{
       try {
           PreparedStatement pr =Database.getStmt(sql, args);
           try {
               return pr.executeUpdate();
           } finally {
               pr.getConnection().close();
           }
       } catch (Exception e) {
           throw new RuntimeException(e);
       }
   }
    public static ResultSet query(String sql,Object...args)throws SQLException{
       PreparedStatement pr = Database.getStmt(sql, args);
       return pr.executeQuery();
   }
    public static Object value(String sql,Object...args){
        try {
            ResultSet rs = Database.query(sql, args);
            if(rs.next()){
                return rs.getObject(0);
            }
            rs.getStatement().getConnection().close();
            return null;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
   }       
}
