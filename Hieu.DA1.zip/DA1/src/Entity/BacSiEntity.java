package Entity;


public class BacSiEntity {

    private int id, idKhoa;
    private String tenBS, diaChi;
    private String ngaySinh;
    private String  SDT;
    private boolean gioiTinh;

    public BacSiEntity() {
    }

    public BacSiEntity(int id, int idKhoa, String tenBS, String diaChi, String ngaySinh, String SDT, boolean gioiTinh) {
        this.id = id;
        this.idKhoa = idKhoa;
        this.tenBS = tenBS;
        this.diaChi = diaChi;
        this.ngaySinh = ngaySinh;
        this.SDT = SDT;
        this.gioiTinh = gioiTinh;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdKhoa() {
        return idKhoa;
    }

    public void setIdKhoa(int idKhoa) {
        this.idKhoa = idKhoa;
    }

    public String getTenBS() {
        return tenBS;
    }

    public void setTenBS(String tenBS) {
        this.tenBS = tenBS;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(String ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

    public boolean isGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(boolean gioiTinh) {
        this.gioiTinh = gioiTinh;
    }


   
    
    
}
