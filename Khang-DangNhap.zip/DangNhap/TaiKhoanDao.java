package Dao;

import Entity.TaiKhoanEntity;
import dao.Database;
import java.sql.*;

public class TaiKhoanDao {
    public TaiKhoanEntity selectByID(String TaiKhoan){
        try {
            Connection con = Database.getConnection();
            String sql = "SELECT * FROM TaiKhoan WHERE ID_BS = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, TaiKhoan);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                TaiKhoanEntity tkE = new TaiKhoanEntity(resu.getInt("ID_BS"), resu.getString("TaiKhoan"), resu.getString("MatKhau"));
                return tkE;
            }
            
        } catch (SQLException e) {
            System.out.println("SelectByID that bai" + e);
        }
        return null;
    }
}
