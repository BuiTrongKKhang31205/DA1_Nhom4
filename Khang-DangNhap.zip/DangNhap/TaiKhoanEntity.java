package Entity;

public class TaiKhoanEntity {
    private int ID_BS;
    private String TaiKhoan, MatKhau;

    public TaiKhoanEntity() {
    }

    public TaiKhoanEntity(int ID_BS, String TaiKhoan,String MatKhau) {
        this.ID_BS = ID_BS;
        this.TaiKhoan = TaiKhoan;
        this.MatKhau = MatKhau;
    }

    public int getID_BS() {
        return ID_BS;
    }

    public void setID_BS(int ID_BS) {
        this.ID_BS = ID_BS;
    }

    public String getMatKhau() {
        return MatKhau;
    }

    public void setMatKhau(String MatKhau) {
        this.MatKhau = MatKhau;
    }

    public String getTaiKhoan() {
        return TaiKhoan;
    }

    public void setTaiKhoan(String TaiKhoan) {
        this.TaiKhoan = TaiKhoan;
    }
    
    
}
