/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Entity.SoKhamEntity;
import dao.Database;
import java.util.List;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author buitr
 */
public class SoKhamDao {
    Connection con = Database.getConnection();
    public List<SoKhamEntity> getAllSoKham(){
        List<SoKhamEntity> lsSoKham = new ArrayList<>();
        try {
            String sql = "SELECT * FROM SoKham";
            PreparedStatement pre = con.prepareStatement(sql);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                SoKhamEntity skE = new SoKhamEntity(resu.getString("MaSoKham"), resu.getInt("ID_BN"));
                lsSoKham.add(skE);
            }
        } catch (SQLException e) {
            System.out.println("Lay du lieu so kham that bai" + e);
        }
        return lsSoKham;
    }
    public void insert(SoKhamEntity skE){
        try {
            Connection con = Database.getConnection();
            String sql = "INSERT INTO SoKham (MaSoKham, ID_BN) VALUES(?,?)";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, skE.getMaSoKham());
            pre.setInt(2, skE.getID_BN());
            if(pre.executeUpdate() > 0){
                System.out.println("INSERT thanh cong");
            }else{
                System.out.println("INSERT that bai");
            }
        } catch (SQLException e) {
            System.out.println("Them that bai" + e);
        }
    }
    
    public void update(SoKhamEntity skE){
        try {
            Connection con = Database.getConnection();
            String sql = "UPDATE SoKham SET ID_BN = ? WHERE MaSoKham = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, skE.getID_BN());
            pre.setString(2, skE.getMaSoKham());
            if(pre.executeUpdate() > 0){
                System.out.println("UPDATE thanh cong");
            }else{
                System.out.println("UPDATE that bai");
            }
        } catch (SQLException e) {
            System.out.println("Update that bai" + e);
        }
    }
    
    public void delete(SoKhamEntity skE){
        try {
            Connection con = Database.getConnection();
            String sql = "DELETE FROM SoKham WHERE MaSoKham = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, skE.getMaSoKham());
            if(pre.executeUpdate() > 0){
                System.out.println("Delete thanh cong");
            }else{
                System.out.println("Delete that bai");
            }
        } catch (SQLException e) {
            System.out.println("Delete that bai" + e);
        }
    }
    
    public SoKhamEntity selectByID(String SoKham){
        try {
            Connection con = Database.getConnection();
            String sql = "SELECT * FROM SoKham WHERE MaSoKham = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, SoKham);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                SoKhamEntity skE = new SoKhamEntity(resu.getString("MaSoKham"), resu.getInt("ID_BN"));
                return skE;
            }
            
        } catch (SQLException e) {
            System.out.println("SelectByID that bai" + e);
        }
        return null;
    }
}
