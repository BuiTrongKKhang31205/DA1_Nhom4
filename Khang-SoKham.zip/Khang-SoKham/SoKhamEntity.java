package Entity;

public class SoKhamEntity {
    private String MaSoKham;
    private int ID_BN;

    public SoKhamEntity() {
    }

    public SoKhamEntity(String MaSoKham, int ID_BN) {
        this.MaSoKham = MaSoKham;
        this.ID_BN = ID_BN;
    }

    public String getMaSoKham() {
        return MaSoKham;
    }

    public void setMaSoKham(String MaSoKham) {
        this.MaSoKham = MaSoKham;
    }

    public int getID_BN() {
        return ID_BN;
    }

    public void setID_BN(int ID_BN) {
        this.ID_BN = ID_BN;
    }
    
}
