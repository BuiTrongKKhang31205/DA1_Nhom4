/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Entity.BacSiEntity;
import java.util.*;
import java.sql.*;

/**
 *
 * @author buitr
 */
public class BacSiDao {

    public List<BacSiEntity> getAllBacSi() {
        List<BacSiEntity> listBS = new ArrayList<>();
        try {
            Connection con = Database.getConnect();
            String sql = "SELECT * FROM BACSI ";
            PreparedStatement pre = con.prepareStatement(sql);
            ResultSet resu = pre.executeQuery();
            while (resu.next()) {
                BacSiEntity bsE = new BacSiEntity(resu.getString("MaBS"), resu.getString("TenBS"), resu.getString("ChucVu"), resu.getString("Id_Khoa"), resu.getString("NamSinh"),
                        resu.getString("DiaChi"), resu.getString("SDT"), resu.getBoolean("gioiTinh"));

                listBS.add(bsE);
            }
        } catch (SQLException e) {
            System.out.println("Lay du lieu Bac Si that bai" + e);
        }
        return listBS;
    }

    public void add(BacSiEntity bs) {
        try {
            Connection con = Database.getConnect();
            String sql = "INSERT INTO BACSI (MaBS = ?, TenBS = ?, ChucVu = ?, Id_Khoa = ?, NamSinh = ?, DiaChi = ?, SDT = ?, GioiTinh = ?) VALUES(?,?,?,?,?,?,?)";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, bs.getMaBS());
            pre.setString(2, bs.getTenBS());
            pre.setString(3, bs.getChucVu());
            pre.setString(4, bs.getIdKhoa());
            pre.setString(5, bs.getNamSinh());
            pre.setString(6, bs.getDiaChi());
            pre.setString(7, bs.getSDT());
            pre.setBoolean(8, bs.isGioiTinh());

            if (pre.executeUpdate() > 0) {
                System.out.println("INSERT thanh cong");
            } else {
                System.out.println("INSERT that bai");
            }
        } catch (SQLException e) {
            System.out.println("Them bac si that bai" + e);
        }
    }

    public void update(BacSiEntity bs) {
        try {
            Connection con = Database.getConnect();
            String sql = "UPDATE BACSI SET TenBS = ?, ChucVu = ?, Id_Khoa = ?,NamSinh = ?, DiaChi = ?, SDT = ?, GioiTinh = ?, WHERE MaBS = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, bs.getTenBS());
            pre.setString(2, bs.getChucVu());
            pre.setString(3, bs.getIdKhoa());
            pre.setString(4, bs.getNamSinh());
            pre.setString(5, bs.getDiaChi());
            pre.setString(6, bs.getSDT());
            pre.setBoolean(7, bs.isGioiTinh());
            pre.setString(8, bs.getMaBS());
            if (pre.executeUpdate() > 0) {
                System.out.println("UPDATE thanh cong");
            } else {
                System.out.println("UPDATE that bai");
            }
        } catch (SQLException e) {
            System.out.println("Cap nhat bac si that bai" + e);
        }
    }

    public void delete(BacSiEntity bs) {
        try {
            Connection con = Database.getConnect();
            String sql = "DELETE FROM BACSI WHERE MaBS = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, bs.getMaBS());
            if (pre.executeUpdate() > 0) {
                System.out.println("Delete thanh cong");
            } else {
                System.out.println("Delete that bai");
            }
        } catch (SQLException e) {
            System.out.println("Delete that bai" + e);
        }
    }

    public BacSiEntity selectByID(String BacSi) {
        try {
            Connection con = Database.getConnect();
            String sql = "SELECT * FROM BACSI WHERE MaBS = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, BacSi);
            ResultSet resu = pre.executeQuery();
            while (resu.next()) {
                BacSiEntity bs = new BacSiEntity(resu.getString("MaBS"), resu.getString("TenBS"), resu.getString("ChucVu"), resu.getString("Id_Khoa"), resu.getString("NamSinh"),
                        resu.getString("DiaChi"), resu.getString("SDT"), resu.getBoolean("gioiTinh"));
                return bs;
            }

        } catch (SQLException e) {
            System.out.println("SelectByID that bai" + e);
        }
        return null;
    }
}
