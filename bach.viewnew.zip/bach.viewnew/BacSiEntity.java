/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

/**
 *
 * @author buitr
 */
public class BacSiEntity {

    private String maBS, tenBS, chucVu, idKhoa, namSinh;
    private String diaChi, SDT;
    private boolean gioiTinh;

    public BacSiEntity() {
    }

    public BacSiEntity(String maBS, String tenBS, String chucVu, String idKhoa, String namSinh, String diaChi, String SDT, boolean gioiTinh) {
        this.maBS = maBS;
        this.tenBS = tenBS;
        this.chucVu = chucVu;
        this.idKhoa = idKhoa;
        this.namSinh = namSinh;
        this.diaChi = diaChi;
        this.SDT = SDT;
        this.gioiTinh = gioiTinh;
    }

    public String getMaBS() {
        return maBS;
    }

    public void setMaBS(String maBS) {
        this.maBS = maBS;
    }

    public String getTenBS() {
        return tenBS;
    }

    public void setTenBS(String tenBS) {
        this.tenBS = tenBS;
    }

    public String getChucVu() {
        return chucVu;
    }

    public void setChucVu(String chucVu) {
        this.chucVu = chucVu;
    }

    public String getIdKhoa() {
        return idKhoa;
    }

    public void setIdKhoa(String idKhoa) {
        this.idKhoa = idKhoa;
    }

    public String getNamSinh() {
        return namSinh;
    }

    public void setNamSinh(String namSinh) {
        this.namSinh = namSinh;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

    public boolean isGioiTinh() {
        return gioiTinh;
    }

    public void setGioiTinh(boolean gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

}
