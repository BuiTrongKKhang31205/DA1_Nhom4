/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;
import Entity.BenhNhanEntity;
import dao.Database;
import java.sql.*;
import java.util.*;


/**
 *
 * @author buitr
 */
public class BenhNhanDao {
    Connection con = Database.getConnection();
    public List<BenhNhanEntity> getAll(){
        List<BenhNhanEntity> lbn = new ArrayList<>();
        try {
            String sql = "select * from BenhNhan";
            PreparedStatement pr = con.prepareStatement(sql);
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                BenhNhanEntity bn = new BenhNhanEntity(rs.getInt("ID"), rs.getString("HoTenBN"), rs.getString("DiaChi"),
                        rs.getBoolean("GioiTinh"), rs.getString("SDT"), rs.getString("NgaySinh"));
                lbn.add(bn);
            }
        } catch (SQLException e) {
            System.out.println("Loi lay du lieu" + e);
        }
        return lbn;
    }
    public void insert(BenhNhanEntity bn){
        try {
            String sql = "INSERT INTO BenhNhan (HoTenBN,DiaChi,GioiTinh,SDT,NgaySinh) VALUES(?,?,?,?,?)";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1, bn.getHoTenBN());
            pr.setString(2, bn.getDiaChi());
            pr.setBoolean(3, bn.isGioiTinh());
            pr.setString(4, bn.getSDT());
            pr.setString(5, bn.getNgaySinh());
            if(pr.executeUpdate() > 0){
                System.out.println("insert thanh cong");
            }else {
                System.out.println("insert that bai");
            }
        } catch (SQLException e) {
            System.out.println("loi them " + e);
        }
    }
    public void update(BenhNhanEntity bn){
        try {
            String sql = "UPDATE BenhNhan set HoTenBN = ?, DiaChi = ?, GioiTinh = ?, SDT = ?, NgaySinh = ? WHERE ID = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1, bn.getHoTenBN());
            pr.setString(2, bn.getDiaChi());
            pr.setBoolean(3, bn.isGioiTinh());
            pr.setString(4, bn.getSDT());
            pr.setString(5, bn.getNgaySinh());
            pr.setInt(6, bn.getID());            
            if(pr.executeUpdate() > 0){
                System.out.println("update thanh cong");
            }else {
                System.out.println("update that bai");
            }
        } catch (SQLException e) {
            System.out.println("loi sua " + e);
        }
    }
    public void delete(int ID){
        try {
            String sql = "DELETE FROM BenhNhan WHERE ID = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setInt(1, ID);
            if(pr.executeUpdate() > 0){
                System.out.println("delete thanh cong");
            }else {
                System.out.println("delete that bai");
            }
        } catch (SQLException e) {
            System.out.println("loi xoa " + e);
        }
    }
    public BenhNhanEntity selectByID(int ID){
        try {
            String sql = "SELECT * FROM BenhNhan WHERE ID = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setInt(1, ID);
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                BenhNhanEntity bn = new BenhNhanEntity(rs.getInt("ID"), rs.getString("HoTenBN"), rs.getString("DiaChi"),
                        rs.getBoolean("GioiTinh"), rs.getString("SDT"), rs.getString("NgaySinh"));
                return bn;
            }            
        } catch (SQLException e) {
            System.out.println("loi tim" + e);
        }
        return null;
    }
public BenhNhanEntity selectByTenBNAndIDSK(String tenBN, int idSK) {
    try {
        String sql = "SELECT bn.* FROM BenhNhan bn Inner JOIN SoKham sk ON bn.ID = sk.ID_BN WHERE bn.HoTenBN LIKE ? AND sk.ID = ?";
        PreparedStatement pr = con.prepareStatement(sql);
        pr.setString(1, tenBN);
        pr.setInt(2, idSK);
        ResultSet rs = pr.executeQuery();
        while(rs.next()) {
            BenhNhanEntity bn = new BenhNhanEntity(rs.getInt("ID"), rs.getString("HoTenBN"), rs.getString("DiaChi"),
                    rs.getBoolean("GioiTinh"), rs.getString("SDT"), rs.getString("NgaySinh"));
            return bn;
        }
    } catch (SQLException e) {
        System.out.println("Lỗi: " + e);
    }
    return null;
}
    public BenhNhanEntity selectByTen(String tenBN){
        try {
            String sql = "SELECT * FROM BenhNhan WHERE HoTenBN = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1, tenBN);
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                BenhNhanEntity bn = new BenhNhanEntity(rs.getInt("ID"), rs.getString("HoTenBN"), rs.getString("DiaChi"),
                        rs.getBoolean("GioiTinh"), rs.getString("SDT"), rs.getString("NgaySinh"));
                return bn;
            }            
        } catch (SQLException e) {
            System.out.println("loi tim" + e);
        }
        return null;
    }   
    public List<BenhNhanEntity> search(String HoTenBN, String SDT){
        List<BenhNhanEntity> lbn = new ArrayList<>();
        try {
            String sql = "select * from BenhNhan where HoTenBN like ? OR SDT like ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1, HoTenBN);
            pr.setString(2, SDT);            
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                BenhNhanEntity bn = new BenhNhanEntity(rs.getInt("ID"), rs.getString("HoTenBN"), rs.getString("DiaChi"),
                        rs.getBoolean("GioiTinh"), rs.getString("SDT"), rs.getString("NgaySinh"));
                lbn.add(bn);
            }
        } catch (SQLException e) {
            System.out.println("Loi lay du lieu" + e);
        }
        return lbn;
    }
    public List<BenhNhanEntity> tinhTuoi(int ID){
        List<BenhNhanEntity> lbn = new ArrayList<>();
        try {
        String sql = "SELECT ID, HoTenBN, DiaChi, GioiTinh, SDT, DATEDIFF(YEAR, NgaySinh, GETDATE()) AS Age FROM BenhNhan WHERE ID = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setInt(1, ID);           
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                BenhNhanEntity bn = new BenhNhanEntity(rs.getInt("ID"), rs.getString("HoTenBN"), rs.getString("DiaChi"),
                        rs.getBoolean("GioiTinh"), rs.getString("SDT"), rs.getString("Age"));
                lbn.add(bn);
            }
        } catch (SQLException e) {
            System.out.println("Loi lay du lieu" + e);
        }
        return lbn;
    }    
}
