/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;
import Entity.KhoaEntity;
import dao.Database;
import java.util.*;
import java.sql.*;
/**
 *
 * @author buitr
 */
public class KhoaDao {
    Connection con = Database.getConnection();
    public List<KhoaEntity> getAllKhoa(){
        List<KhoaEntity> listKH = new ArrayList<>();
        try {

            String sql = "SELECT * FROM Khoa";
            PreparedStatement pre = con.prepareStatement(sql);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                KhoaEntity khE = new KhoaEntity(resu.getInt("ID"), resu.getString("TenKhoa"), resu.getString("ViTri"));
                listKH.add(khE);
            }
        } catch (SQLException e) {
            System.out.println("Lay du lieu Khoa that bai" + e);
        }
        return listKH;
    }
    public void add(KhoaEntity kh){
        try {

            String sql = "INSERT INTO KHOA (TenKhoa, ViTri) VALUES(?,?)";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, kh.getTenKhoa());
            pre.setString(2, kh.getViTri());
            
            if(pre.executeUpdate() > 0){
                System.out.println("INSERT thanh cong");
            }else{
                System.out.println("INSERT that bai");
            }
        } catch (SQLException e) {
            System.out.println("Them khoa that bai" + e);
        }
    }
    public void update(KhoaEntity kh){
        try {

            String sql = "UPDATE KHOA SET TenKhoa = ?, ViTri = ? WHERE ID = ?";
            PreparedStatement pre = con.prepareStatement(sql);            
            pre.setString(1, kh.getTenKhoa());
            pre.setString(2, kh.getViTri());
            pre.setInt(3, kh.getID());
            
            if(pre.executeUpdate() > 0){
                System.out.println("UPDATE thanh cong");
            }else{
                System.out.println("UPDATE that bai");
            }
        } catch (SQLException e) {
            System.out.println("Cap nhat khoa that bai" + e);
        }
    }
    public void delete(int  id){
        try {

            String sql = "DELETE FROM KHOA WHERE ID = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, id);
            if(pre.executeUpdate() > 0){
                System.out.println("Delete thanh cong");
            }else{
                System.out.println("Delete that bai");
            }
        } catch (SQLException e) {
            System.out.println("Delete that bai" + e);
        }
    }
    public KhoaEntity selectByID(int id){
        try {

            String sql = "SELECT * FROM KHOA WHERE ID = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setInt(1, id);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                KhoaEntity kh = new KhoaEntity(resu.getInt("ID"), resu.getString("TenKhoa"), resu.getString("ViTri"));
                return kh;
            }
            
        } catch (SQLException e) {
            System.out.println("SelectByID that bai" + e);
        }
        return null;
    }
    public KhoaEntity selectByTen(String tenKhoa){
        try {

            String sql = "SELECT * FROM KHOA WHERE tenKhoa = ?";
            PreparedStatement pre = con.prepareStatement(sql);
            pre.setString(1, tenKhoa);
            ResultSet resu = pre.executeQuery();
            while(resu.next()){
                KhoaEntity kh = new KhoaEntity(resu.getInt("ID"), resu.getString("TenKhoa"), resu.getString("ViTri"));
                return kh;
            }
            
        } catch (SQLException e) {
            System.out.println("SelectByID that bai" + e);
        }
        return null;
    }    
}
