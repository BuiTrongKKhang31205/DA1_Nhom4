/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Entity.BenhNhanEntity;
import Entity.SoKhamEntity;
import dao.Database;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 *
 * @author buiva
 */
public class ThongKeDao {
    Connection con = Database.getConnection();
    private List<Object[]> getListOfArray(String sql, String[] cols, Object...args){
        try {
            List<Object[]> list = new ArrayList<>();
            ResultSet rs = Database.query(sql, args);
            while(rs.next()){
                Object[] vals = new Object[cols.length];
                for(int i = 0; i < cols.length; i++){
                    vals[i] = rs.getObject(cols[i]);
                }
                list.add(vals);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException();
            
        }
    }
    public List<Object[]> getBacSi(Integer nam){
        String sql = "{CALL P_BacSi(?)}";
        String[] cols = {"TenBS","TenKhoa","SoLuongSK"};
        return getListOfArray(sql, cols, nam);
    }
    public List<Object[]> getBenhNhan(){
        String sql = "{CALL P_BenhNhan}";
        String[] cols = {"Nam","SoLuong"};
        return getListOfArray(sql, cols);
    }    
    public List<Object[]> getMacBenh(Integer nam){
        String sql = "{CALL P_MacBenh(?)}";
        String[] cols = {"ChuanDoan","SoBN"};
        return getListOfArray(sql, cols, nam);
    }
    public List<Object[]> getTuoi(){
        String sql = "{CALL P_TinhTuoiBN}";
        String [] cols = {"idBN","Age"};
        return getListOfArray(sql, cols);
    }
   
    public void taoBieuDoTuoi(JPanel jp){
        DefaultCategoryDataset dataset = new DefaultCategoryDataset(); 

        List<Object[]> list = getTuoi();
    
        if (list != null) {
            int treEmCount = 0;
            int thanhThieuNienCount = 0;
            int treCount = 0;
            int trungNienCount = 0;
            int nguoiCaoTuoiCount = 0;

            for (Object[] obj : list) {
                int age = (int) obj[1]; 

                if (age < 13) {
                    treEmCount++;
                } else if (age >= 13 && age <= 19) {
                    thanhThieuNienCount++;
                } else if (age >= 20 && age <= 34) {
                    treCount++;
                } else if (age >= 35 && age <= 64) {
                    trungNienCount++;
                } else {
                    nguoiCaoTuoiCount++;
                }
            }

        dataset.addValue(treEmCount, "Mắc bệnh", "Trẻ em");
        dataset.addValue(thanhThieuNienCount, "Mắc bệnh", "Thanh thiếu niên");
        dataset.addValue(treCount, "Mắc bệnh", "Trẻ");
        dataset.addValue(trungNienCount, "Mắc bệnh", "Trung niên");
        dataset.addValue(nguoiCaoTuoiCount, "Mắc bệnh", "Người cao tuổi");
    }

        
        JFreeChart barChart = ChartFactory.createBarChart(
                "Biểu đồ thống kê độ tuổi mắc bệnh".toUpperCase(),
                "Độ tuổi", "Số lượng",
                dataset, PlotOrientation.VERTICAL, false, true, false);

        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new Dimension(jp.getWidth(), 321));

        jp.removeAll();
        jp.setLayout(new CardLayout());
        jp.add(chartPanel);
        
        jp.validate();
        jp.repaint();        
    }
    public void bieuBenhNhan(JPanel jp){
        DefaultCategoryDataset dataset = new DefaultCategoryDataset(); 
        List<Object[]> list = getBenhNhan();
            for (Object[] obj : list) {
                int nam = (int) obj[0]; 
                int sl = (int) obj[1];

        dataset.addValue(sl,"Số lượng", String.valueOf(nam));
    }
        JFreeChart barChart = ChartFactory.createBarChart(
                "Biểu đồ thống kê số lượng bệnh nhân theo năm".toUpperCase(),
                "Năm", "Số lượng",
                dataset, PlotOrientation.VERTICAL, false, true, false);

        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new Dimension(jp.getWidth(), 321));

        jp.removeAll();
        jp.setLayout(new CardLayout());
        jp.add(chartPanel);       
        jp.validate();
        jp.repaint();        
    }    
}
