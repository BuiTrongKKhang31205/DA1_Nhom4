package Entity;

public class KhoaEntity {
    
    private int ID;
    private String  tenKhoa, viTri;

    public KhoaEntity() {
    }

    public KhoaEntity(int ID, String tenKhoa, String viTri) {
        this.ID = ID;
        this.tenKhoa = tenKhoa;
        this.viTri = viTri;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTenKhoa() {
        return tenKhoa;
    }

    public void setTenKhoa(String tenKhoa) {
        this.tenKhoa = tenKhoa;
    }

    public String getViTri() {
        return viTri;
    }

    public void setViTri(String viTri) {
        this.viTri = viTri;
    }
    
    
}
