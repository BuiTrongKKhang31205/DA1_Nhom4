package Entity;

public class TaiKhoanEntity {
    private int ID, idBacSi;
    private String TaiKhoan, MatKhau;
    private boolean vaiTro;

    public TaiKhoanEntity() {
    }

    public TaiKhoanEntity(int ID, int idBacSi, String TaiKhoan, String MatKhau, boolean vaiTro) {
        this.ID = ID;
        this.idBacSi = idBacSi;
        this.TaiKhoan = TaiKhoan;
        this.MatKhau = MatKhau;
        this.vaiTro = vaiTro;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getIdBacSi() {
        return idBacSi;
    }

    public void setIdBacSi(int idBacSi) {
        this.idBacSi = idBacSi;
    }

    public String getTaiKhoan() {
        return TaiKhoan;
    }

    public void setTaiKhoan(String TaiKhoan) {
        this.TaiKhoan = TaiKhoan;
    }

    public String getMatKhau() {
        return MatKhau;
    }

    public void setMatKhau(String MatKhau) {
        this.MatKhau = MatKhau;
    }

    public boolean isVaiTro() {
        return vaiTro;
    }

    public void setVaiTro(boolean vaiTro) {
        this.vaiTro = vaiTro;
    }
 
}
