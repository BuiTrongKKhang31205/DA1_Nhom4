/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Item;

/**
 *
 * @author buiva
 */
public class Item {
    private int id;
    private String ten;

    public Item() {
    }

    public Item(int id, String ten) {
        this.id = id;
        this.ten = ten;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTen() {
        return ten;
    }

    public void setTenBN(String ten) {
        this.ten = ten;
    }
    @Override
    public String toString(){
        return ten;
    }
}
