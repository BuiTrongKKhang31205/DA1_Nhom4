/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package View;

import Dao.BacSiDao;
import Dao.BenhNhanDao;
import Dao.KhoaDao;
import Dao.SoKhamDao;
import Entity.BacSiEntity;
import Entity.BenhNhanEntity;
import Entity.KhoaEntity;
import Entity.SoKhamEntity;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import utils.Auth;



/**
 *
 * @author buiva
 */
public class SoKhamJP extends javax.swing.JPanel {
    private BenhNhanDao bnd = new BenhNhanDao();
    private SoKhamDao skd = new SoKhamDao();
    private BacSiDao bsd = new BacSiDao();
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private List<BenhNhanEntity> lbn = new ArrayList<>();
    private List<BacSiEntity> lbs = new ArrayList<>();
    private KhoaDao kd = new KhoaDao();
    private SoKhamEntity skE = new SoKhamEntity();
    private List<SoKhamEntity> lsk = new ArrayList<>();
    int row = 0;
    public SoKhamJP() {
        initComponents();
        
        fillTableBSToDay();
        updateStatus();
        EventButton();
        lblToday.setText("Sổ khám chờ ngày: " + dateFormat.format(new Date()));
    }

    public void fillTableBN(List<BenhNhanEntity> lbn) {
        String tenBN =  (String) tblBangSK.getValueAt(row, 2);
        BenhNhanEntity bnEntity = bnd.selectByTen(tenBN);
        if (bnEntity != null) {
            DefaultTableModel model = (DefaultTableModel) tblBangBN.getModel();
            model.setRowCount(0);
            model.addRow(new Object[]{bnEntity.getID(), bnEntity.getHoTenBN(), bnEntity.getNgaySinh(), bnEntity.isGioiTinh() ? "Nữ" : "Nam",bnEntity.getDiaChi(),bnEntity.getSDT()});
        }
    }
    public void fillTableBS(List<BacSiEntity> lbs){
        String tenBS =  (String) tblBangSK.getValueAt(row, 5);
        BacSiEntity bsEntity = bsd.selectByTen(tenBS);
        if(bsEntity != null){
            DefaultTableModel model = (DefaultTableModel) tblBangBS.getModel();
            model.setRowCount(0);
            KhoaEntity kE = kd.selectByID(bsEntity.getIdKhoa());
            model.addRow(new Object[] {bsEntity.getId(),bsEntity.getTenBS(),kE.getTenKhoa()});
        }
    }
    
    public void EventButton(){
            jrHienThi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                if(jrHienThi.isSelected()){
                    fillTable();
                    lblToday.setText("Tất cả dữ liệu sổ khám");
                }else{
                    fillTableBSToDay();
        lblToday.setText("Sổ khám chờ ngày: " + dateFormat.format(new Date()));
                    
            }
            
        }
    });        
       

                }
    public String convertTrangThaiToString(int trangThai) {
    switch (trangThai) {
        case 0:
            return "Chờ Khám";
        case 1:
            return "Đang điều trị";
        case 2:
            return "Khám xong";
        default:
            return "Unknown";
    }
}
    public void fillTableBSToDay(){
        DefaultTableModel model = (DefaultTableModel) tblBangSK.getModel();
        model.setRowCount(0);
        for(SoKhamEntity skE : skd.getAllSoKham()){
            if(Auth.isManager()){
                if(skE.getId_BS() == Auth.user.getIdBacSi() && skE.getNgayKham().equals(dateFormat.format(new Date()))){
                BenhNhanEntity bnE = bnd.selectByID(skE.getId_BN());
                BacSiEntity bsE_Yta = bsd.selectByID(skE.getId_YTa());
                BacSiEntity bsE_BS = bsd.selectByID(skE.getId_BS());


                KhoaEntity kE = kd.selectByID(skE.getId_Khoa());
                model.addRow(new Object[] {skE.getId(), bsE_Yta.getTenBS(), bnE.getHoTenBN(), skE.getTinhTrangBenh(),kE.getTenKhoa(),bsE_BS.getTenBS(),
                    skE.getChiDinh(), skE.getChuanDoan(),skE.getToaThuoc(),skE.getNgayKham(),skE.getNgayHenKhamLai(),
                    skE.getGhiChu(),convertTrangThaiToString(skE.getTrangThai())});                
                }                
            }else{
               if( skE.getNgayKham().equals(dateFormat.format(new Date()))){
                BenhNhanEntity bnE = bnd.selectByID(skE.getId_BN());
                BacSiEntity bsE_Yta = bsd.selectByID(skE.getId_YTa());
                BacSiEntity bsE_BS = bsd.selectByID(skE.getId_BS());


                KhoaEntity kE = kd.selectByID(skE.getId_Khoa());
                model.addRow(new Object[] {skE.getId(), bsE_Yta.getTenBS(), bnE.getHoTenBN(), skE.getTinhTrangBenh(),kE.getTenKhoa(),bsE_BS.getTenBS(),
                    skE.getChiDinh(), skE.getChuanDoan(),skE.getToaThuoc(),skE.getNgayKham(),skE.getNgayHenKhamLai(),
                    skE.getGhiChu(),convertTrangThaiToString(skE.getTrangThai())});                 
            }
        }
        }
        tblBangSK.setModel(model);
    }
    public void fillTable(){
        DefaultTableModel model = (DefaultTableModel) tblBangSK.getModel();
        model.setRowCount(0);
        for(SoKhamEntity skE : skd.getAllSoKham()){
            BenhNhanEntity bnE = bnd.selectByID(skE.getId_BN());
            BacSiEntity bsE_Yta = bsd.selectByID(skE.getId_YTa());
            BacSiEntity bsE_BS = bsd.selectByID(skE.getId_BS());
            KhoaEntity kE = kd.selectByID(skE.getId_Khoa());
            model.addRow(new Object[] {skE.getId(), bsE_Yta.getTenBS(), bnE.getHoTenBN(), skE.getTinhTrangBenh(),kE.getTenKhoa(),bsE_BS.getTenBS(),
                skE.getChiDinh(), skE.getChuanDoan(),skE.getToaThuoc(),skE.getNgayKham(),skE.getNgayHenKhamLai(),
                skE.getGhiChu(),convertTrangThaiToString(skE.getTrangThai())});                
            }
        
        tblBangSK.setModel(model);        
    }
    

    
    public void update(){       
        row = tblBangSK.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một hàng trong bảng trước khi sửa.");
            return;
        }        
        int id = (int) tblBangSK.getValueAt(row, 0);
        int option = JOptionPane.showConfirmDialog(this, "Bạn chắc muốn sửa ko?");
        if(option == JOptionPane.YES_NO_OPTION){
            SoKhamEntity skE = getForm();
            skE.setId(id);
            skd.updateSoKham(skE);
            jrHienThi.isSelected();
            JOptionPane.showMessageDialog(this, "Sua Thanh cong");
            if(jrHienThi.isSelected()){
                fillTable();
            }else{
                fillTableBSToDay();
            }           
        }        
    }
    
    public void delete(){
        row = tblBangSK.getSelectedRow();
        if (row == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một hàng trong bảng trước khi xóa.");
        return;
    }    
        int id = (int) tblBangSK.getValueAt(row, 0);
        int option = JOptionPane.showConfirmDialog(this, "Bạn chắc xóa ko?");
        if(option == JOptionPane.YES_NO_OPTION){
        skd.delete(id);
        JOptionPane.showMessageDialog(this, "Xoa Thanh cong");
            if(jrHienThi.isSelected()){
                fillTable();
            }else{
                fillTableBSToDay();
            }              
        }   
    }
    
   public void first(){
        row = 0;
        edit();
    }
   
    public void prev(){
        if(row > 0){
            row--;
            edit();
            
        }
    }
    
    public void next(){
        if(row < tblBangSK.getRowCount() - 1){
            row++;
            edit();
        }
    }
    
    public void last(){
        row = tblBangSK.getRowCount() - 1;
        edit();
    }
    
    public void edit(){
        try {
            int id = (int) tblBangSK.getValueAt(row, 0);
            SoKhamEntity skE = skd.selectByID(id);
            if(skE != null){
                setForm(skE);
                updateStatus();
            }
        } catch (Exception e) {
            System.out.println("loi edit"+e);
        }
    
    }
    
    public void clearForm(){

        teaChuanDoan.setText("");
        teaToaThuoc.setText("");
        teaGhiChu.setText("");
        jdcNgayHenKhamLai.setDate(null);
        jrChoKham.setSelected(true);
        jrDangDT.setSelected(false);
        teaChiDinh.setText("");
        this.row = -1;
        updateStatus();
        
    }
    
    public SoKhamEntity getForm(){
        int id = 0;
        int idBS = Auth.user.getIdBacSi();
        String chiDinh = teaChiDinh.getText();
        String chuanDoan = teaChuanDoan.getText();
        String toaThuoc = teaToaThuoc.getText();
        String ngayKham = dateFormat.format(new Date());
        Date ngayHen = jdcNgayHenKhamLai.getDate();
        String ngayHenKhamLai = ngayHen != null ? dateFormat.format(ngayHen) : null; // Nếu ngày hẹn là null, sẽ lưu giá trị null

        String ghiChu = teaGhiChu.getText();
    int trangThai = 0; // Mặc định là Chờ Khám

    if (jrChoKham.isSelected()) {
        trangThai = 0; // Chờ Khám
    } else if (jrDangDT.isSelected()) {
        trangThai = 1; // Đang điều trị
    } else if (jrKhamXong.isSelected()) {
        trangThai = 2; // Khám xong
    }
        String ttb = skE.getTinhTrangBenh();
       SoKhamEntity skE = new SoKhamEntity(id, 0, 0, ttb, 0, idBS, chiDinh, toaThuoc, chuanDoan, ngayKham, ngayHenKhamLai, ghiChu, trangThai);

        return skE;
    }

    public void setForm(SoKhamEntity skE){
        try {
            teaChiDinh.setText(skE.getChiDinh());
            teaChuanDoan.setText(skE.getChuanDoan());
            teaToaThuoc.setText(skE.getToaThuoc());
            teaGhiChu.setText(skE.getGhiChu());
            
        if (skE.getNgayHenKhamLai() != null) {
            jdcNgayHenKhamLai.setDate(new SimpleDateFormat("yyyy-MM-dd").parse(skE.getNgayHenKhamLai()));
        } else {
            jdcNgayHenKhamLai.setDate(null);
        }
        
        if (skE.getTrangThai() == 0) {
            jrChoKham.setSelected(true);
        } else if (skE.getTrangThai() == 1) {
            jrDangDT.setSelected(true);
        } else if (skE.getTrangThai() == 2) {
            jrKhamXong.setSelected(true);
        }
        } catch (Exception e) {
            System.out.println("loi setForm"+e);
        }
    }
    
    public void updateStatus(){
        boolean edit = this.row >=0;
        boolean first = this.row ==0;
        boolean last = this.row == tblBangSK.getRowCount() - 1;
        
        btnSua.setEnabled(edit);
        btnXoa.setEnabled(edit);
        
        btnFirst.setEnabled(edit && !first);
        btnPrev.setEnabled(edit && !first);
        btnNext.setEnabled(edit && !last);
        btnLast.setEnabled(edit && !last);        
        
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblBangBN1 = new javax.swing.JTable();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        LichSuKham = new javax.swing.JMenuItem();
        jPanel4 = new javax.swing.JPanel();
        btnPrev = new javax.swing.JButton();
        btnFirst = new javax.swing.JButton();
        btnLast = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBangSK = new javax.swing.JTable();
        lblToday = new javax.swing.JLabel();
        jrHienThi = new javax.swing.JRadioButton();
        btnIn = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblBangBN = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        btnNew = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        teaGhiChu = new javax.swing.JTextArea();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        teaChuanDoan = new javax.swing.JTextArea();
        jScrollPane5 = new javax.swing.JScrollPane();
        teaToaThuoc = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        jrChoKham = new javax.swing.JRadioButton();
        jrDangDT = new javax.swing.JRadioButton();
        jdcNgayHenKhamLai = new com.toedter.calendar.JDateChooser();
        jScrollPane8 = new javax.swing.JScrollPane();
        teaChiDinh = new javax.swing.JTextArea();
        jrKhamXong = new javax.swing.JRadioButton();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblBangBS = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();

        jPanel6.setBackground(new java.awt.Color(204, 204, 204));
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Bệnh nhân"));

        tblBangBN1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID_BN", "Tên Bệnh nhân", "Ngày sinh", "Giới tính"
            }
        ));
        jScrollPane6.setViewportView(tblBangBN1);
        if (tblBangBN1.getColumnModel().getColumnCount() > 0) {
            tblBangBN1.getColumnModel().getColumn(2).setHeaderValue("");
        }

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        LichSuKham.setText("Lịch sử khám");
        LichSuKham.setName("Lịch sử khám"); // NOI18N
        LichSuKham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LichSuKhamActionPerformed(evt);
            }
        });
        jPopupMenu1.add(LichSuKham);

        setBackground(new java.awt.Color(255, 255, 255));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnPrev.setText("<<");
        btnPrev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrevActionPerformed(evt);
            }
        });

        btnFirst.setText("|<");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        btnLast.setText(">|");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        btnNext.setText(">>");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        tblBangSK.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Tên Y tá", "Tên bệnh nhân", "Tình trạng bệnh", "Tên Khoa", "Tên bác sĩ", "Chỉ định", "Chuẩn đoán", "Toa thuốc", "Ngày khám", "Ngày hẹn khám lại", "Ghi chú", "Trạng thái"
            }
        ));
        tblBangSK.setGridColor(new java.awt.Color(255, 255, 255));
        tblBangSK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblBangSKMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                tblBangSKMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tblBangSK);

        lblToday.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblToday.setText("Sổ khám chờ ngày :    ");

        jrHienThi.setText("Hiện tất cả dữ liệu bảng");
        jrHienThi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrHienThiActionPerformed(evt);
            }
        });

        btnIn.setText("In phiếu khám");
        btnIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInActionPerformed(evt);
            }
        });

        jLabel7.setText("Chú thích: Khi click chuột phải vào 1 dòng ở bảng sổ khám thì  sẽ hiển thị ra lịch sử khám của bệnh nhân đó ");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1197, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(btnIn, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(72, 72, 72)
                        .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(169, 169, 169)
                        .addComponent(btnFirst, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnPrev, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnNext, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnLast, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(lblToday, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jrHienThi)))
                .addGap(46, 46, 46))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblToday)
                    .addComponent(jrHienThi))
                .addGap(18, 40, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnPrev)
                    .addComponent(btnFirst)
                    .addComponent(btnLast)
                    .addComponent(btnNext)
                    .addComponent(btnIn)
                    .addComponent(jLabel7))
                .addGap(22, 22, 22))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Bệnh nhân"));

        tblBangBN.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID_BN", "Tên Bệnh nhân", "Ngày sinh", "Giới tính", "Địa chỉ", "SDT"
            }
        ));
        jScrollPane3.setViewportView(tblBangBN);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnNew.setText("Mới");
        btnNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewActionPerformed(evt);
            }
        });

        jLabel3.setText("Chuẩn đoán");

        jLabel8.setText("Ghi chú");

        teaGhiChu.setColumns(20);
        teaGhiChu.setRows(5);
        jScrollPane2.setViewportView(teaGhiChu);

        btnSua.setText("Sửa");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnXoa.setText("Xóa");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        jLabel4.setText("Ngày hẹn khám lại");

        jLabel6.setText("Toa thuốc");

        jLabel1.setText("Chỉ định");

        teaChuanDoan.setColumns(20);
        teaChuanDoan.setRows(5);
        jScrollPane4.setViewportView(teaChuanDoan);

        teaToaThuoc.setColumns(20);
        teaToaThuoc.setRows(5);
        jScrollPane5.setViewportView(teaToaThuoc);

        jLabel5.setText("Trạng thái");

        buttonGroup1.add(jrChoKham);
        jrChoKham.setText("Chờ khám");

        buttonGroup1.add(jrDangDT);
        jrDangDT.setText("Đang điều trị");

        teaChiDinh.setColumns(20);
        teaChiDinh.setRows(5);
        jScrollPane8.setViewportView(teaChiDinh);

        buttonGroup1.add(jrKhamXong);
        jrKhamXong.setText("Khám xong");
        jrKhamXong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jrKhamXongActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(18, 18, 18))
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(38, 38, 38)))
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jScrollPane8)
                                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(jdcNgayHenKhamLai, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(250, 250, 250))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addGap(42, 42, 42)
                                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                        .addGap(67, 67, 67)
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addContainerGap(19, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(jrChoKham)
                        .addGap(18, 18, 18)
                        .addComponent(jrDangDT)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jrKhamXong)
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSua)
                .addGap(61, 61, 61)
                .addComponent(btnXoa)
                .addGap(55, 55, 55)
                .addComponent(btnNew)
                .addGap(224, 224, 224))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 84, Short.MAX_VALUE)
                        .addComponent(jLabel8)
                        .addGap(82, 82, 82))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(jLabel1)
                                .addGap(67, 67, 67)
                                .addComponent(jLabel3))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                                    .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 59, Short.MAX_VALUE))
                                .addGap(32, 32, 32)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jdcNgayHenKhamLai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jrChoKham)
                    .addComponent(jrDangDT)
                    .addComponent(jrKhamXong))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNew)
                    .addComponent(btnXoa)
                    .addComponent(btnSua))
                .addGap(19, 19, 19))
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Bác sĩ"));

        tblBangBS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID Bác sĩ", "Tên bác sĩ", "Tên khoa"
            }
        ));
        jScrollPane7.setViewportView(tblBangBS);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        jLabel2.setText("QUẢN LÝ SỔ KHÁM");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(20, 20, 20))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(444, 444, 444))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void tblBangSKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBangSKMouseClicked
        row = tblBangSK.getSelectedRow();
        edit();
        BenhNhanEntity bnEntity = new BenhNhanEntity();
        bnEntity.setHoTenBN((String) tblBangSK.getValueAt(row, 2));
        lbn.add(bnEntity);
        fillTableBN(lbn);
        BacSiEntity bsEntity = new BacSiEntity();
        bsEntity.setTenBS((String) tblBangSK.getValueAt(row, 5));
        lbs.add(bsEntity);
        fillTableBS(lbs);
        

    }//GEN-LAST:event_tblBangSKMouseClicked

    private void btnNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewActionPerformed
                clearForm();
    }//GEN-LAST:event_btnNewActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        if(Auth.isManager()){
            update();
        }else{
            JOptionPane.showMessageDialog(this, "Bạn không có quyền truy cập");
        }      

    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        if(Auth.isManager()){
            delete();
        }else{
            JOptionPane.showMessageDialog(this, "Bạn không có quyền truy cập");
        } 
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        first();
    }//GEN-LAST:event_btnFirstActionPerformed

    private void btnPrevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrevActionPerformed
        prev();
    }//GEN-LAST:event_btnPrevActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        next();
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        last();
    }//GEN-LAST:event_btnLastActionPerformed

    private void jrHienThiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrHienThiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jrHienThiActionPerformed

    private void tblBangSKMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblBangSKMouseReleased
        if(evt.isPopupTrigger()){
            jPopupMenu1.show(tblBangSK,evt.getX(),evt.getY());
        }
        
        
    }//GEN-LAST:event_tblBangSKMouseReleased

    private void LichSuKhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LichSuKhamActionPerformed
        if(Auth.isManager()){
            row = tblBangSK.getSelectedRow();
                int selectedSoKhamID = (int) tblBangSK.getValueAt(row, 0);
                if(selectedSoKhamID != -1){
                    SoKhamEntity selectedSoKham = skd.selectByID(selectedSoKhamID);
                    JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);// Lấy thông tin từ dòng đã chọn
                    int id_BN = selectedSoKham.getId_BN();
                    BenhNhanEntity bnE = bnd.selectByID(id_BN);
                    List<SoKhamEntity> lsk = skd.getAllByNameHistory(bnE.getHoTenBN());
                    LichSuKham lichSuKham = new LichSuKham(frame, true,lsk ); // Truyền thông tin vào JDialog
                    lichSuKham.setDefaultCloseOperation(frame.DISPOSE_ON_CLOSE);
                    lichSuKham.pack();
                    lichSuKham.setLocationRelativeTo(frame);
                    lichSuKham.setVisible(true);                   
                }else{
                    JOptionPane.showMessageDialog(this, "Bạn click vào dòng");
                }
        }else{
            JOptionPane.showMessageDialog(this, "Bạn không có quyền truy cập");
        }         
    }//GEN-LAST:event_LichSuKhamActionPerformed

    private void jrKhamXongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jrKhamXongActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jrKhamXongActionPerformed

    private void btnInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInActionPerformed
        if(Auth.isManager()){
            
        int rowSK = tblBangSK.getSelectedRow();
        if(rowSK == -1){
            JOptionPane.showMessageDialog(this, "Bạn chưa chọn dòng để in");
        }
        String fontPath = "src\\font\\UTM Swiss 721 Black Condensed.ttf";
        BaseFont baseFont = null;
        try {
            baseFont = BaseFont.createFont(fontPath, BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
        } catch (DocumentException | java.io.IOException e) {
            e.printStackTrace();
        }

        // Tạo Font sử dụng BaseFont vừa tạo
        Font vietnameseFont = new Font(baseFont, 12, Font.NORMAL);
        // tạo một document
        Document document = new Document();
        try {

       
            Random random = new Random();
            int rd = random.nextInt(999999);
            PdfWriter.getInstance(document, new FileOutputStream("src\\inPhieuKham\\phieukham" + rd + ".pdf"));
            document.open();
            
            document.add(new Paragraph("--------------------------------------------------------------------------------------------------------------------------")); 
            Calendar now = Calendar.getInstance();
            int day = now.get(Calendar.DAY_OF_MONTH);
            int month = now.get(Calendar.MONTH) + 1; // Tháng bắt đầu từ 0 nên cần +1
            int year = now.get(Calendar.YEAR);
            document.add(new Paragraph("ID: " + tblBangSK.getValueAt(rowSK, 0)+"                                                                                       " + "Hải phòng, ngày "+day + " tháng " +month+ " năm " + year, vietnameseFont));
            Paragraph p = new Paragraph("Phiếu khám bệnh viện", new Font(baseFont, 20, Font.NORMAL));
            p.setAlignment(Element.ALIGN_CENTER);
            document.add(p);
            document.add(new Paragraph(" "));  
            String tenBN =  (String) tblBangSK.getValueAt(rowSK, 2);
            int idSK = (int) tblBangSK.getValueAt( rowSK,0);
            BenhNhanEntity bnE = bnd.selectByTenBNAndIDSK(tenBN,idSK);  
            
            String ngaySinhStr = bnE.getNgaySinh();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date ngaySinhDate = sdf.parse(ngaySinhStr);

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(ngaySinhDate);
            int namSinh = calendar.get(Calendar.YEAR);            
            document.add(new Paragraph("Họ và tên: " + tblBangSK.getValueAt(rowSK, 2), vietnameseFont));
            document.add(new Paragraph("Địa chỉ: " + bnE.getDiaChi(), vietnameseFont));
            document.add(new Paragraph("SDT: " + bnE.getSDT(), vietnameseFont));
            document.add(new Paragraph("Năm sinh: " + namSinh, vietnameseFont));
            
            document.add(new Paragraph(" "));             
            PdfPTable itemsTable = new PdfPTable(2);
            itemsTable.addCell(new PdfPCell(new Phrase("Tên bác sĩ", vietnameseFont)));             
            itemsTable.addCell(new PdfPCell(new Phrase("Ngày hẹn khám lại", vietnameseFont)));

                    try {
                        String tenBacSi = tblBangSK.getValueAt(rowSK, 5).toString();                        
                        String  ngayHenKhamLai = tblBangSK.getValueAt(rowSK, 10).toString();


                        itemsTable.addCell(new PdfPCell(new Phrase(tenBacSi, vietnameseFont)));
                        itemsTable.addCell(new PdfPCell(new Phrase(ngayHenKhamLai, vietnameseFont)));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
         
            document.add(itemsTable);            
            document.add(new Paragraph(" "));            
            document.add(new Paragraph("Chuẩn đoán: ", vietnameseFont));
            document.add(new Paragraph("    - " + tblBangSK.getValueAt(rowSK, 7), vietnameseFont)); 
            document.add(new Paragraph("Toa thuốc: ", vietnameseFont));
            document.add(new Paragraph("    - " + tblBangSK.getValueAt(rowSK, 8), vietnameseFont));             
            document.add(new Paragraph("Lời dặn: ", vietnameseFont));
            document.add(new Paragraph("    - " + tblBangSK.getValueAt(rowSK, 11), vietnameseFont));            
            

            document.add(new Paragraph(" "));




            document.add(new Paragraph(" "));
            Paragraph p2 = new Paragraph("               KHÁCH HÀNG"+            "                                     BÁC SĨ", new Font(baseFont, 20, Font.NORMAL));
            document.add(p2);  
            document.add(new Paragraph("                            (Ký và ghi rõ họ tên) " + "                                                     (Ký và ghi rõ họ tên)", vietnameseFont));

            JOptionPane.showMessageDialog(this, "tạo phiếu khám thành công");

            document.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    try {
        // Đường dẫn tới tệp PDF vừa tạo
        String filePDF = "src\\inPhieuKham\\";
        
        // Mở tệp PDF bằng mặc định ứng dụng xem PDF trên máy tính
        File file = new File(filePDF);
        if (file.exists()) {
            Desktop.getDesktop().open(file);
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy tệp PDF để mở.");
        }
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Đã xảy ra lỗi khi mở tệp PDF.");
    } 
        }else{
            JOptionPane.showMessageDialog(this, "Bạn không có quyền truy cập");
        }
         
    }//GEN-LAST:event_btnInActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem LichSuKham;
    private javax.swing.JButton btnFirst;
    private javax.swing.JButton btnIn;
    private javax.swing.JButton btnLast;
    private javax.swing.JButton btnNew;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btnPrev;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnXoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private com.toedter.calendar.JDateChooser jdcNgayHenKhamLai;
    private javax.swing.JRadioButton jrChoKham;
    private javax.swing.JRadioButton jrDangDT;
    private javax.swing.JRadioButton jrHienThi;
    private javax.swing.JRadioButton jrKhamXong;
    private javax.swing.JLabel lblToday;
    private javax.swing.JTable tblBangBN;
    private javax.swing.JTable tblBangBN1;
    private javax.swing.JTable tblBangBS;
    private javax.swing.JTable tblBangSK;
    private javax.swing.JTextArea teaChiDinh;
    private javax.swing.JTextArea teaChuanDoan;
    private javax.swing.JTextArea teaGhiChu;
    private javax.swing.JTextArea teaToaThuoc;
    // End of variables declaration//GEN-END:variables
}
