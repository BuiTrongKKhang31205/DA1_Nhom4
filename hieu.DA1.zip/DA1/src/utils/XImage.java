package utils;

import java.awt.Image;
import java.net.URL;
import javax.swing.ImageIcon;

public class XImage {
    public static Image getIcon(){
        URL url = XImage.class.getResource("/icon/fpt.png/");
        return new ImageIcon(url).getImage();
    }
}
