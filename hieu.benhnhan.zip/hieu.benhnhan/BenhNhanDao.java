/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;
import Entity.BenhNhanEntity;
import dao.Database;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author buitr
 */
public class BenhNhanDao {
    Connection con = Database.getConnection();
    public List<BenhNhanEntity> getAll(){
        List<BenhNhanEntity> lbn = new ArrayList<>();
        try {
            String sql = "select * from BenhNhan";
            PreparedStatement pr = con.prepareStatement(sql);
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                BenhNhanEntity bn = new BenhNhanEntity(rs.getString("MaBN"), rs.getString("HoTenBN"), rs.getString("DiaChi"),
                        rs.getBoolean("GioiTinh"), rs.getString("SDT"), rs.getString("NgaySinh"));
                lbn.add(bn);
            }
        } catch (SQLException e) {
            System.out.println("Loi lay du lieu" + e);
        }
        return lbn;
    }
    public void insert(BenhNhanEntity bn){
        try {
            String sql = "INSERT INTO BenhNhan (HoTenBN,DiaChi,GioiTinh,SDT,NgaySinh) VALUES (?,?,?,?,?)";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1, bn.getHoTenBN());
            pr.setString(2, bn.getDiaChi());
            pr.setBoolean(3, bn.isGioiTinh());
            pr.setString(4, bn.getSDT());
            pr.setString(5, bn.getNgaySinh());
            if(pr.executeUpdate() > 0){
                System.out.println("insert thanh cong");
            }else {
                System.out.println("insert that bai");
            }
        } catch (SQLException e) {
            System.out.println("loi them " + e);
        }
    }
    public void update(BenhNhanEntity bn){
        try {
            String sql = "UPDATE BenhNhan set HoTenBN = ?, DiaChi = ?, GioiTinh = ?, SDT = ?, NgaySinh = ? WHERE MaBN = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(6, bn.getMaBN());
            pr.setString(1, bn.getHoTenBN());
            pr.setString(2, bn.getDiaChi());
            pr.setBoolean(3, bn.isGioiTinh());
            pr.setString(4, bn.getSDT());
            pr.setString(5, bn.getNgaySinh());
            if(pr.executeUpdate() > 0){
                System.out.println("update thanh cong");
            }else {
                System.out.println("update that bai");
            }
        } catch (SQLException e) {
            System.out.println("loi sua " + e);
        }
    }
    public void delete(String maBN){
        try {
            String sql = "DELETE FROM BenhNhan WHERE MaBN = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1, maBN);
            if(pr.executeUpdate() > 0){
                System.out.println("delete thanh cong");
            }else {
                System.out.println("delete that bai");
            }
        } catch (SQLException e) {
            System.out.println("loi xoa " + e);
        }
    }
    public BenhNhanEntity selectByID(String maBN){
        try {
            String sql = "SELECT * FROM BenhNhan WHERE MaBN = ?";
            PreparedStatement pr = con.prepareStatement(sql);
            pr.setString(1, maBN);
            ResultSet rs = pr.executeQuery();
            while(rs.next()){
                BenhNhanEntity bn = new BenhNhanEntity(rs.getString("MaBN"), rs.getString("HoTenBN"), rs.getString("DiaChi"),
                        rs.getBoolean("GioiTinh"), rs.getString("SDT"), rs.getString("NgaySinh"));
                return bn;
            }            
        } catch (SQLException e) {
            System.out.println("loi tim" + e);
        }
        return null;
    }

}
