package Entity;

public class KhoaEntity {

    private String idKhoa, tenKhoa, viTri;

    public KhoaEntity() {
    }

    public KhoaEntity(String idKhoa, String tenKhoa, String viTri) {
        this.idKhoa = idKhoa;
        this.tenKhoa = tenKhoa;
        this.viTri = viTri;
    }

    public String getIdKhoa() {
        return idKhoa;
    }

    public void setIdKhoa(String idKhoa) {
        this.idKhoa = idKhoa;
    }

    public String getTenKhoa() {
        return tenKhoa;
    }

    public void setTenKhoa(String tenKhoa) {
        this.tenKhoa = tenKhoa;
    }

    public String getViTri() {
        return viTri;
    }

    public void setViTri(String viTri) {
        this.viTri = viTri;
    }
    
}
